SentinalsPrime Phase 3

Purpose
-------
1. Reduce the global desktop density without CSS transform/zoom hacks.
2. Constrain CTFd public pages to the original CTF-Platform max-w-6xl width.
3. Make Challenges and challenge modal more compact.
4. Replace the stock Scoreboard markup with a native CTFd/Alpine/ECharts
   presentation styled like CTF-Platform. CTFd remains responsible for all data.

Install
-------
Overlay this folder into:
  ~/CTFd/CTFd/themes/sentinalsprime/

Then add this near the TOP of assets/scss/main.scss, with the other @use lines:
  @use "includes/phase3";

Do NOT put @use at the bottom.

Then:
  cd ~/CTFd/CTFd/themes/sentinalsprime
  yarn build
  cd ~/CTFd
  docker compose restart

Hard refresh the browser (Ctrl+Shift+R).

Rollback
--------
Remove:
  assets/scss/includes/_phase3.scss

Restore templates/scoreboard.html from core if desired, and remove:
  @use "includes/phase3";
