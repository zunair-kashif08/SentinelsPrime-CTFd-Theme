SentinalsPrime Phase 6 — Scoreboard Timeline
============================================

Why the graph looked empty
--------------------------
CTFd's native scoreboard graph creates one data point per solve. If a user
has only one solve, ECharts receives one point and therefore cannot draw a
line segment.

Phase 6 keeps CTFd's native getScoreboardDetail() and getOption() flow, then
expands every series to:

  [competition/start, 0]
  [solve 1, cumulative score]
  [solve 2, cumulative score]
  ...
  [now or event end, final cumulative score]

With ECharts `step: "end"` this produces the expected CTF scoreboard:
flat score -> vertical jump on solve -> flat -> next jump.

Timeline improvements
---------------------
- X-axis includes internal left/right time padding.
- First and last labels no longer touch the tactical frame.
- <=12 hours: HH:MM
- <=3 days: date + time
- <=45 days: month/day
- long events: month/year
- The graph extends to now while the CTF is live.
- When Configs.end is in the past, the graph ends at the configured event end.
- Y-axis dynamically adds headroom above the highest score.
- Stock CTFd dataZoom and toolbox remain removed.
- Legend remains scrollable for many users.

Install
-------
Overlay into:
  ~/CTFd/CTFd/themes/sentinalsprime/

There is still only one custom SCSS:
  assets/scss/includes/_sentinalsprime.scss

main.scss should have only:
  @use "includes/sentinalsprime";

Then:
  cd ~/CTFd/CTFd/themes/sentinalsprime
  yarn build
  cd ~/CTFd
  docker compose restart

Hard refresh:
  Ctrl + Shift + R

Expected behavior
-----------------
If a user solves:
  04:30 -> +50
  05:10 -> +100

their line is:
  0 ─────┐
         └──── 50 ─────────┐
                           └──── 150 ──────>

The final horizontal segment keeps extending as time advances.
