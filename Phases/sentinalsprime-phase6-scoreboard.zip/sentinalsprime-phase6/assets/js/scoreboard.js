import Alpine from "alpinejs";
import CTFd from "./index";
import { getOption } from "./utils/graphs/echarts/scoreboard";
import { embed } from "./utils/graphs/echarts";

window.Alpine = Alpine;
window.CTFd = CTFd;

const scoreboardUpdateInterval =
  window.scoreboardUpdateInterval || 300000;

const COLORS = [
  "#ef4444",
  "#3b82f6",
  "#10b981",
  "#f59e0b",
  "#8b5cf6",
  "#ec4899",
  "#06b6d4",
  "#eab308",
  "#84cc16",
  "#14b8a6",
];

const MINUTE = 60 * 1000;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;

function toTimestamp(value) {
  if (value instanceof Date) {
    return value.getTime();
  }

  const timestamp =
    typeof value === "number"
      ? value
      : new Date(value).getTime();

  return Number.isFinite(timestamp) ? timestamp : null;
}

function parseConfiguredTime(value) {
  if (value === null || value === undefined || value === "") {
    return null;
  }

  // CTFd can expose timestamps as ISO strings or unix values.
  if (typeof value === "number") {
    // Handle both seconds and milliseconds.
    return value < 100000000000
      ? value * 1000
      : value;
  }

  const asNumber = Number(value);
  if (Number.isFinite(asNumber) && String(value).trim() !== "") {
    return asNumber < 100000000000
      ? asNumber * 1000
      : asNumber;
  }

  const parsed = new Date(value).getTime();
  return Number.isFinite(parsed) ? parsed : null;
}

function getTimelineBounds(option) {
  const timestamps = [];

  for (const series of option.series || []) {
    for (const point of series.data || []) {
      const ts = Array.isArray(point)
        ? toTimestamp(point[0])
        : null;

      if (ts !== null) {
        timestamps.push(ts);
      }
    }
  }

  if (!timestamps.length) {
    return null;
  }

  const earliestSolve = Math.min(...timestamps);
  const latestSolve = Math.max(...timestamps);

  const configuredStart =
    parseConfiguredTime(window.init?.start);
  const configuredEnd =
    parseConfiguredTime(window.init?.end);

  const now = Date.now();

  /*
   * Start at the configured competition start when useful.
   * Otherwise give the first solve a small lead-in so the jump is visible.
   */
  let domainStart =
    configuredStart !== null &&
    configuredStart <= earliestSolve
      ? configuredStart
      : earliestSolve - HOUR;

  /*
   * A live CTF extends the plateau to "now".
   * An ended CTF extends to its configured end.
   * Always guarantee at least an hour after the latest solve so a single
   * solve creates a visible horizontal segment.
   */
  let liveEnd = now;

  if (
    configuredEnd !== null &&
    configuredEnd < now
  ) {
    liveEnd = configuredEnd;
  }

  let domainEnd = Math.max(
    latestSolve + HOUR,
    liveEnd,
  );

  if (domainEnd <= domainStart) {
    domainEnd = domainStart + HOUR;
  }

  /*
   * Add small internal domain padding. This prevents the first/last axis
   * labels and the line from sitting directly on the tactical frame.
   */
  const span = domainEnd - domainStart;
  const padding = Math.max(
    10 * MINUTE,
    Math.min(2 * HOUR, span * 0.035),
  );

  return {
    domainStart: domainStart - padding,
    dataStart: domainStart,
    dataEnd: domainEnd,
    domainEnd: domainEnd + padding,
    span: span + padding * 2,
  };
}

function formatTimelineLabel(value, span) {
  const date = new Date(value);

  if (span <= 12 * HOUR) {
    return date.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  if (span <= 3 * DAY) {
    const day = date.toLocaleDateString([], {
      month: "short",
      day: "numeric",
    });

    const time = date.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });

    return `${day}\n${time}`;
  }

  if (span <= 45 * DAY) {
    return date.toLocaleDateString([], {
      month: "short",
      day: "numeric",
    });
  }

  return date.toLocaleDateString([], {
    month: "short",
    year: "2-digit",
  });
}

function expandSeriesTimeline(option, bounds) {
  let highestScore = 0;

  (option.series || []).forEach((series, index) => {
    const normalized = (series.data || [])
      .map((point) => {
        if (!Array.isArray(point) || point.length < 2) {
          return null;
        }

        const timestamp = toTimestamp(point[0]);
        const score = Number(point[1]);

        if (
          timestamp === null ||
          !Number.isFinite(score)
        ) {
          return null;
        }

        return [timestamp, score];
      })
      .filter(Boolean)
      .sort((a, b) => a[0] - b[0]);

    const lastScore =
      normalized.length
        ? normalized[normalized.length - 1][1]
        : 0;

    highestScore = Math.max(
      highestScore,
      lastScore,
      ...normalized.map((point) => point[1]),
    );

    /*
     * This is the key fix:
     *
     * [competition start, 0]
     * [solve #1, cumulative score]
     * [solve #2, cumulative score]
     * ...
     * [current/event end, final score]
     *
     * With step:"end", every solve produces a vertical jump and the score
     * remains horizontal until the next solve.
     */
    series.data = [
      [bounds.dataStart, 0],
      ...normalized,
      [bounds.dataEnd, lastScore],
    ];

    const color = COLORS[index % COLORS.length];

    series.type = "line";
    series.step = "end";
    series.smooth = false;
    series.showSymbol = false;
    series.connectNulls = true;
    series.symbol = "circle";
    series.symbolSize = 7;

    series.lineStyle = {
      width: 2.4,
      color,
      shadowBlur: 5,
      shadowColor: `${color}55`,
    };

    series.itemStyle = {
      color,
      borderColor: "#050505",
      borderWidth: 2,
    };

    series.emphasis = {
      focus: "series",
      lineStyle: {
        width: 3,
      },
    };
  });

  return highestScore;
}

function makeScoreboardBeautiful(option) {
  const bounds = getTimelineBounds(option);

  option.backgroundColor = "transparent";

  option.title = {
    ...(option.title || {}),
    show: false,
    text: "",
  };

  option.toolbox = {
    show: false,
    feature: {},
  };

  // Remove CTFd's stock zoom slider completely.
  option.dataZoom = [];

  option.tooltip = {
    ...(option.tooltip || {}),
    trigger: "axis",
    backgroundColor: "rgba(5,5,5,.96)",
    borderColor: "rgba(127,29,29,.72)",
    borderWidth: 1,
    padding: 12,
    textStyle: {
      color: "#cbd5e1",
      fontSize: 12,
      fontFamily:
        "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
    },
    axisPointer: {
      type: "line",
      lineStyle: {
        color: "rgba(239,68,68,.34)",
        width: 1,
      },
    },
  };

  option.legend = {
    ...(option.legend || {}),
    type: "scroll",
    orient: "horizontal",
    left: "center",
    bottom: 0,
    itemWidth: 9,
    itemHeight: 9,
    icon: "circle",
    pageIconColor: "#ef4444",
    pageIconInactiveColor: "#475569",
    pageTextStyle: {
      color: "#64748b",
    },
    textStyle: {
      color: "#94a3b8",
      fontSize: 11,
      fontFamily:
        "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
    },
  };

  option.grid = {
    top: 18,
    right: 34,
    bottom: 58,
    left: 18,
    containLabel: true,
  };

  let highestScore = 0;

  if (bounds) {
    highestScore =
      expandSeriesTimeline(option, bounds);
  }

  if (Array.isArray(option.xAxis) && option.xAxis[0]) {
    const xAxis = option.xAxis[0];

    xAxis.type = "time";
    xAxis.boundaryGap = false;

    if (bounds) {
      xAxis.min = bounds.domainStart;
      xAxis.max = bounds.domainEnd;
    }

    xAxis.splitNumber = 6;
    xAxis.axisLine = {
      show: true,
      lineStyle: {
        color: "#475569",
        width: 1,
      },
    };

    xAxis.axisTick = {
      show: true,
      alignWithLabel: true,
      lineStyle: {
        color: "#475569",
      },
    };

    xAxis.axisLabel = {
      color: "#64748b",
      fontSize: 11,
      fontFamily:
        "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
      margin: 13,
      hideOverlap: true,
      formatter: (value) =>
        formatTimelineLabel(
          value,
          bounds?.span || HOUR,
        ),
    };

    xAxis.splitLine = {
      show: false,
    };
  }

  if (Array.isArray(option.yAxis) && option.yAxis[0]) {
    const yAxis = option.yAxis[0];

    yAxis.type = "value";
    yAxis.min = 0;

    /*
     * Give the highest line ~15% headroom instead of pinning it against
     * the top border. For tiny scores, retain a sensible minimum range.
     */
    if (highestScore > 0) {
      const padded = highestScore * 1.18;
      const magnitude =
        Math.pow(
          10,
          Math.max(
            0,
            Math.floor(Math.log10(padded)) - 1,
          ),
        );

      yAxis.max =
        Math.ceil(padded / magnitude) * magnitude;
    }

    yAxis.splitNumber = 5;

    yAxis.axisLine = {
      show: true,
      lineStyle: {
        color: "#475569",
        width: 1,
      },
    };

    yAxis.axisTick = {
      show: false,
    };

    yAxis.axisLabel = {
      color: "#64748b",
      fontSize: 11,
      fontFamily:
        "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
      margin: 12,
    };

    yAxis.splitLine = {
      show: true,
      lineStyle: {
        color: "rgba(220,38,38,.14)",
        type: "dashed",
      },
    };
  }

  return option;
}

Alpine.data("ScoreboardDetail", () => ({
  data: {},
  show: true,
  activeBracket: null,

  async update() {
    this.data =
      await CTFd.pages.scoreboard.getScoreboardDetail(
        10,
        this.activeBracket,
      );

    /*
     * Keep CTFd's own cumulative-score generator as the base so the data
     * model stays compatible with CTFd, then add start/end timeline points.
     */
    let option = getOption(
      CTFd.config.userMode,
      this.data,
      null,
    );

    option = makeScoreboardBeautiful(option);

    if (Object.keys(this.data).length > 0) {
      embed(this.$refs.scoregraph, option);
      this.show = true;
    } else {
      this.show = false;
    }
  },

  async init() {
    await this.update();

    setInterval(() => {
      this.update();
    }, scoreboardUpdateInterval);
  },
}));

Alpine.data("ScoreboardList", () => ({
  standings: [],
  brackets: [],
  activeBracket: null,

  async update() {
    this.brackets =
      await CTFd.pages.scoreboard.getBrackets(
        CTFd.config.userMode,
      );

    this.standings =
      await CTFd.pages.scoreboard.getScoreboard();
  },

  async init() {
    this.$watch("activeBracket", value => {
      this.$dispatch("bracket-change", value);
    });

    await this.update();

    setInterval(() => {
      this.update();
    }, scoreboardUpdateInterval);
  },
}));

Alpine.start();
