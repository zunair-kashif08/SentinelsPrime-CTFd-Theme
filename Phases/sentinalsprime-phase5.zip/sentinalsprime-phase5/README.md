SentinalsPrime Phase 5
======================

This patch fixes the three regressions reported after Phase 4.

1) Challenge + Settings/Token popups
------------------------------------
The backdrop is now visual-only (`pointer-events:none`), and all known
SentinalsPrime modal ancestors have their stacking contexts neutralized.

Additionally, the Challenge modal was structurally moved outside
`.sp-page-shell`, while remaining inside the native CTFd `ChallengeBoard`
Alpine scope.

There is also a small critical modal rule in base.html so an old cached
compiled stylesheet cannot make dialogs unclickable.

2) Scoreboard
-------------
The Phase 4 custom `SentinalsScoreboard` Alpine component is removed.

Phase 5 uses the same native component names and API flow as current CTFd:
  ScoreboardDetail
  ScoreboardList
  CTFd.pages.scoreboard.getScoreboardDetail()
  CTFd.pages.scoreboard.getScoreboard()
  CTFd.pages.scoreboard.getBrackets()

Only the ECharts option is changed:
  - no CTFd title
  - no stock dataZoom slider
  - no toolbox
  - tactical red/dark grid
  - CTF-Platform color palette
  - step-after lines
  - custom red/black ranking table

3) Favicon
----------
Do not put the favicon directly in `static/img`.

CTFd's Vite build writes to `static/` and copies `assets/img/**` to
`static/img`. Therefore this patch stores:
  assets/img/favicon.svg
  assets/img/favicon.png

base.html references those files with a cache-busting query string.

INSTALL
=======

rm -rf /tmp/sp5
mkdir -p /tmp/sp5
unzip /path/to/sentinalsprime-phase5.zip -d /tmp/sp5

cp -a /tmp/sp5/sentinalsprime-phase5/. \
  ~/CTFd/CTFd/themes/sentinalsprime/

Use ONE custom SCSS import only.

Near the TOP of:
  ~/CTFd/CTFd/themes/sentinalsprime/assets/scss/main.scss

keep:
  @use "includes/sentinalsprime";

Remove any:
  @use "includes/phase3";

Then:

cd ~/CTFd/CTFd/themes/sentinalsprime

rm -f assets/scss/includes/_phase3.scss

# optional but useful while debugging stale build output
rm -rf static

yarn build

Verify the build recreated the favicons:
  ls -lh static/img/favicon.svg static/img/favicon.png

Verify direct HTTP asset access from another machine/browser:
  http://YOUR-IP/themes/sentinalsprime/static/img/favicon.svg?v=20260902-5
  http://YOUR-IP/themes/sentinalsprime/static/img/favicon.png?v=20260902-5

Restart:
  cd ~/CTFd
  docker compose restart

Browser:
  Ctrl + Shift + R

IMPORTANT SCOREBOARD CHECK
==========================
After loading /scoreboard, DevTools Network should show:
  /api/v1/scoreboard
  /api/v1/scoreboard/top/10

If either request is red/failed, send its Status + Response.
If both are 200, this template/controller will render the returned data.
