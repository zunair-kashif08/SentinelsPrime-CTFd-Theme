import Alpine from "alpinejs";
import CTFd from "./index";
import { getOption } from "./utils/graphs/echarts/scoreboard";
import { embed } from "./utils/graphs/echarts";

window.Alpine = Alpine;
window.CTFd = CTFd;

const scoreboardUpdateInterval =
  window.scoreboardUpdateInterval || 300000;

const SENTINAL_COLORS = [
  "#ef4444",
  "#3b82f6",
  "#10b981",
  "#f59e0b",
  "#8b5cf6",
  "#ec4899",
  "#06b6d4",
  "#eab308",
  "#84cc16",
  "#14b8a6",
];

function applySentinalsPrimeStyle(option) {
  option.title = {
    ...(option.title || {}),
    show: false,
    text: "",
  };

  // Remove CTFd's stock zoom slider/toolbox completely.
  option.toolbox = {
    show: false,
    feature: {},
  };
  option.dataZoom = [];

  option.grid = {
    ...(option.grid || {}),
    top: 20,
    right: 24,
    bottom: 52,
    left: 8,
    containLabel: true,
  };

  option.tooltip = {
    ...(option.tooltip || {}),
    trigger: "axis",
    backgroundColor: "rgba(5,5,5,.96)",
    borderColor: "rgba(127,29,29,.7)",
    borderWidth: 1,
    textStyle: {
      color: "#cbd5e1",
      fontSize: 12,
      fontFamily: "monospace",
    },
    axisPointer: {
      type: "line",
      lineStyle: {
        color: "rgba(239,68,68,.35)",
      },
    },
  };

  option.legend = {
    ...(option.legend || {}),
    type: "scroll",
    bottom: 0,
    textStyle: {
      color: "#94a3b8",
      fontSize: 11,
      fontFamily: "monospace",
    },
  };

  if (Array.isArray(option.xAxis) && option.xAxis[0]) {
    Object.assign(option.xAxis[0], {
      axisLine: {
        lineStyle: { color: "#475569" },
      },
      axisTick: {
        lineStyle: { color: "#475569" },
      },
      axisLabel: {
        color: "#64748b",
        fontSize: 11,
        fontFamily: "monospace",
      },
      splitLine: {
        show: false,
      },
    });
  }

  if (Array.isArray(option.yAxis) && option.yAxis[0]) {
    Object.assign(option.yAxis[0], {
      axisLine: {
        show: true,
        lineStyle: { color: "#475569" },
      },
      axisTick: {
        show: false,
      },
      axisLabel: {
        color: "#64748b",
        fontSize: 11,
        fontFamily: "monospace",
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "rgba(220,38,38,.15)",
          type: "dashed",
        },
      },
    });
  }

  (option.series || []).forEach((series, index) => {
    const color = SENTINAL_COLORS[index % SENTINAL_COLORS.length];

    series.step = "end";
    series.smooth = false;
    series.showSymbol = false;

    series.lineStyle = {
      ...(series.lineStyle || {}),
      width: 2,
      color,
    };

    series.itemStyle = {
      color,
      borderColor: "#050505",
      borderWidth: 2,
    };
  });

  return option;
}

Alpine.data("ScoreboardDetail", () => ({
  data: {},
  show: true,
  activeBracket: null,

  async update() {
    this.data =
      await CTFd.pages.scoreboard.getScoreboardDetail(
        10,
        this.activeBracket,
      );

    let option = getOption(
      CTFd.config.userMode,
      this.data,
      null,
    );

    option = applySentinalsPrimeStyle(option);

    if (Object.keys(this.data).length > 0) {
      embed(this.$refs.scoregraph, option);
      this.show = true;
    } else {
      this.show = false;
    }
  },

  async init() {
    await this.update();

    setInterval(() => {
      this.update();
    }, scoreboardUpdateInterval);
  },
}));

Alpine.data("ScoreboardList", () => ({
  standings: [],
  brackets: [],
  activeBracket: null,

  async update() {
    this.brackets =
      await CTFd.pages.scoreboard.getBrackets(
        CTFd.config.userMode,
      );

    this.standings =
      await CTFd.pages.scoreboard.getScoreboard();
  },

  async init() {
    this.$watch("activeBracket", value => {
      this.$dispatch("bracket-change", value);
    });

    await this.update();

    setInterval(() => {
      this.update();
    }, scoreboardUpdateInterval);
  },
}));

Alpine.start();
