SentinalsPrime Phase 18 — CUMULATIVE
====================================

Includes all Phase 17 cumulative fixes plus the Phase 18 scoreboard-column
alignment correction.

PHASE 18 CHANGE
---------------
The Scoreboard table now has explicit symmetric desktop geometry:

  Place       16%
  User/Team   68%
  Score       16%

The User/Team header and every account/team name are centered within the
middle 68% column. This puts the middle column on the true visual center of
the scoreboard.

Place stays centered.
Score remains right-aligned, with its header and values sharing the same exact
16% right-side column.

Mobile geometry becomes:

  Place       18%
  User/Team   60%
  Score       22%

This gives score values enough room on narrow screens while keeping the
account column centered.

INSTALL
-------
rm -rf /tmp/sp18
mkdir -p /tmp/sp18

unzip /path/to/sentinalsprime-phase18-cumulative.zip -d /tmp/sp18

cp -a /tmp/sp18/sentinalsprime-phase18-cumulative/. \
  ~/CTFd/CTFd/themes/sentinalsprime/

Keep only this custom import near the TOP of assets/scss/main.scss:

  @use "includes/sentinalsprime";

Clean build:

  cd ~/CTFd/CTFd/themes/sentinalsprime
  rm -rf static
  yarn build

Verify:

  grep -R -- '--sentinalsprime-build-phase: 18' \
    static --include='*.css'

Then:

  cd ~/CTFd
  docker compose restart

Hard refresh:

  Ctrl + Shift + R
