SentinalsPrime Phase 13 — CUMULATIVE
====================================

Includes everything from Phase 12:
- working cumulative scoreboard graph
- compact fixed scoreboard tooltip
- notification UI / toast / alert / background support
- notification sound compatibility helpers
- global dark dropdown/native-control fixes

Plus the Phase 13 visible dropdown-arrow enhancement.

WHAT PHASE 13 FIXES
-------------------
The public-theme select fields (for example the Users search filter "Name") were
working, but the dropdown indicator arrow was not visible after custom styling.

Phase 13 adds a consistent custom SVG arrow to all public-theme select controls:
- select
- .form-select
- .custom-select
- select.form-control

The arrow is:
- red by default
- white on hover/focus
- right-aligned with proper padding
- scoped only to the public SentinalsPrime theme
- does not affect /admin

INSTALL
-------
rm -rf /tmp/sp13
mkdir -p /tmp/sp13

unzip /path/to/sentinalsprime-phase13-cumulative.zip -d /tmp/sp13

cp -a /tmp/sp13/sentinalsprime-phase13-cumulative/. \
  ~/CTFd/CTFd/themes/sentinalsprime/

Keep only one custom SCSS import near the top of assets/scss/main.scss:

  @use "includes/sentinalsprime";

Clean build:

  cd ~/CTFd/CTFd/themes/sentinalsprime
  rm -rf static
  yarn build

VERIFY
------
1. Phase marker:
   grep -R -- '--sentinalsprime-build-phase: 13' \
     static --include='*.css'

2. Arrow rule exists:
   grep -R 'background-image: url("data:image/svg+xml' \
     static --include='*.css'

3. Scoreboard entry still exists:
   grep -n '"scoreboard"' static/manifest.json

Restart:

  cd ~/CTFd
  docker compose restart

Then hard refresh:
  Ctrl + Shift + R

EXPECTED RESULT
---------------
The "Name" box and other select fields should now clearly show a dropdown arrow,
so users can immediately recognize that the field is a menu.
