SentinalsPrime Phase 17 — CUMULATIVE
====================================

Includes the cumulative Phase 16 baseline plus these Phase 17 changes:

1. Challenge palette
--------------------
Solved challenge cards now use the same SentinalsPrime combat-red family as
INITIALIZE COMBAT SIM:
- deep black/red gradient
- red status edge
- red SOLVED marker
- light-red score

Unsolved cards no longer use grey. They use a distinct deep tactical navy with
muted steel-blue accents, so solved/unsolved remain visually separate without
breaking the red/black brand.

2. Native dropdown arrow position
---------------------------------
The browser-native dropdown remains enabled. No SVG/data-URI arrow is used.

Phase 15 still had padding-right:1.9rem from the old arrow work. Phase 17 resets
that to .70rem so Chromium's native light-on-dark arrow sits closer to the
right edge of the select.

3. Scoreboard dual hover behavior
---------------------------------
Normal graph hover:
- timestamp
- top 5 competitors at that timestamp
- if CTFd returned more than five graph series, a '+N more' indicator appears

Direct line hover:
- timestamp
- only that exact user/team
- cumulative score at that timestamp

The graph still requests CTFd's native top-10 detail data, and all score
calculation/ranking stays on CTFd.

Phase 17 includes a tiny local override of CTFd's ECharts embed() helper. It is
identical in behavior but returns the ECharts instance, allowing scoreboard.js
to listen for line mouseover/mouseout events. Existing callers can ignore the
return value.

INSTALL
-------
rm -rf /tmp/sp17
mkdir -p /tmp/sp17

unzip /path/to/sentinalsprime-phase17-cumulative.zip -d /tmp/sp17

cp -a /tmp/sp17/sentinalsprime-phase17-cumulative/. \
  ~/CTFd/CTFd/themes/sentinalsprime/

Keep one custom import near the top of assets/scss/main.scss:

  @use "includes/sentinalsprime";

Clean build:

  cd ~/CTFd/CTFd/themes/sentinalsprime
  rm -rf static
  yarn build

VERIFY
------
Phase marker:
  grep -R -- '--sentinalsprime-build-phase: 17' \
    static --include='*.css'

Native select padding:
  grep -R 'padding-right:.70rem' \
    static --include='*.css'

Dual tooltip code:
  grep -R 'AGGREGATE_TOOLTIP_LIMIT' \
    static --include='*.js'

ECharts embed override:
  grep -R 'getInstanceByDom' \
    static --include='*.js'

Restart:

  cd ~/CTFd
  docker compose restart

Then hard refresh:
  Ctrl + Shift + R

TEST
----
1. Users: native arrow should be near the right edge and dropdown should open
   without repeated chevrons.
2. Challenges: solved = combat red; unsolved = deep navy, no grey/green.
3. Scoreboard: move around empty plot area -> top 5 snapshot; move directly
   onto a line -> only that user/team should remain in the tooltip.
