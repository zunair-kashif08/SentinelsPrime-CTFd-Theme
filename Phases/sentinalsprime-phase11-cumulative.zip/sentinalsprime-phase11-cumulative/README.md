SentinalsPrime Phase 11 — CUMULATIVE
====================================

Includes:
- Phase 9 stable notification system
- Phase 10 latest scoreboard graph renderer
- Phase 11 global dropdown/native-control fixes

This is intended to replace the separate Phase 9 + Phase 10 overlays.

DROPDOWN FIX
------------
The Users/Teams search filter is a native <select>. The expanded option menu
was using the browser/OS light palette.

Phase 11 applies:
  color-scheme: dark
to the public theme and explicitly styles:
  select
  option
  optgroup
  .form-select
  .custom-select
  Bootstrap .dropdown-menu / .dropdown-item

It also applies compatible dark styling to:
  date/time picker fields
  file chooser buttons
  Chrome autofill fields
  search cancel buttons

The /admin theme is untouched because all selectors are scoped to .sp-body,
.sp-main, or .sp-navbar.

IMPORTANT NATIVE SELECT LIMITATION
----------------------------------
The actual highlighted row inside an expanded native <select> is partly owned
by the browser/operating system. On Windows/Chrome the selected/hover row may
still use the OS blue selection color. That is normal. The important fix is:
- dark menu background
- readable light text
- no white/grey unreadable option list

If you want 100% custom hover colors for native select options, the control
would need to be replaced with a custom JavaScript dropdown. This patch keeps
CTFd's native form behavior for maximum compatibility.

INSTALL
-------
rm -rf /tmp/sp11
mkdir -p /tmp/sp11

unzip /path/to/sentinalsprime-phase11-cumulative.zip -d /tmp/sp11

cp -a /tmp/sp11/sentinalsprime-phase11-cumulative/. \
  ~/CTFd/CTFd/themes/sentinalsprime/

Your main.scss should keep ONE custom import near the top:

  @use "includes/sentinalsprime";

Clean build:

  cd ~/CTFd/CTFd/themes/sentinalsprime
  rm -rf static
  yarn build

VERIFY BEFORE RESTART
---------------------
Latest CSS marker:

  grep -R -- '--sentinalsprime-build-phase:11' \
    static --include='*.css'

Dropdown rule:

  grep -R 'color-scheme:dark' \
    static --include='*.css'

Scoreboard entry:

  grep -n '"scoreboard"' static/manifest.json

Notification CSS:

  grep -R 'sp-notifications-page' \
    static --include='*.css'

Then restart:

  cd ~/CTFd
  docker compose restart

Browser:
  Ctrl + Shift + R

If the select popup is still white after these grep checks, completely close
the tab/browser and reopen it because native form-popup styling can be held by
the browser process rather than ordinary page cache.
