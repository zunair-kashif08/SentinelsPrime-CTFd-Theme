import Alpine from "alpinejs";
import CTFd from "./index";
import dayjs from "dayjs";

import { getOption } from "./utils/graphs/echarts/scoreboard";
import { embed } from "./utils/graphs/echarts";

window.Alpine = Alpine;
window.CTFd = CTFd;

const UPDATE_INTERVAL =
  window.scoreboardUpdateInterval || 300000;

const MINUTE = 60 * 1000;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;

const COLORS = [
  "#ef4444",
  "#3b82f6",
  "#10b981",
  "#f59e0b",
  "#8b5cf6",
  "#ec4899",
  "#06b6d4",
  "#eab308",
  "#84cc16",
  "#14b8a6",
];

function toMs(value) {
  if (value instanceof Date) {
    return value.getTime();
  }

  if (typeof value === "number") {
    return value < 100000000000
      ? value * 1000
      : value;
  }

  const parsed = dayjs(value);

  return parsed.isValid()
    ? parsed.valueOf()
    : null;
}

function configuredTime(value) {
  if (
    value === undefined ||
    value === null ||
    value === ""
  ) {
    return null;
  }

  if (typeof value === "number") {
    return value < 100000000000
      ? value * 1000
      : value;
  }

  const numeric = Number(value);

  if (
    Number.isFinite(numeric) &&
    String(value).trim() !== ""
  ) {
    return numeric < 100000000000
      ? numeric * 1000
      : numeric;
  }

  const parsed = dayjs(value);

  return parsed.isValid()
    ? parsed.valueOf()
    : null;
}

function collectTimes(option) {
  const times = [];

  for (const series of option.series || []) {
    for (const point of series.data || []) {
      if (!Array.isArray(point)) {
        continue;
      }

      const ms = toMs(point[0]);

      if (ms !== null) {
        times.push(ms);
      }
    }
  }

  return times;
}

function buildTimeline(option) {
  const solveTimes = collectTimes(option);

  if (!solveTimes.length) {
    return null;
  }

  const firstSolve = Math.min(...solveTimes);
  const lastSolve = Math.max(...solveTimes);

  const eventStart =
    configuredTime(window.init?.start);

  const eventEnd =
    configuredTime(window.init?.end);

  const now = Date.now();

  /*
   * If the configured start is meaningfully before the first solve,
   * use it. Otherwise create a short zero-score lead-in so the initial
   * score jump is visible.
   */
  const naturalSpan =
    Math.max(lastSolve - firstSolve, 5 * MINUTE);

  const leadIn =
    Math.max(
      2 * MINUTE,
      Math.min(20 * MINUTE, naturalSpan * 0.18),
    );

  let dataStart;

  if (
    eventStart !== null &&
    eventStart < firstSolve - MINUTE
  ) {
    dataStart = eventStart;
  } else {
    dataStart = firstSolve - leadIn;
  }

  /*
   * While the event is live, extend the final score line to now.
   * If the configured event has ended, stop at its end time.
   */
  let dataEnd;

  if (
    eventEnd !== null &&
    eventEnd <= now
  ) {
    dataEnd =
      Math.max(eventEnd, lastSolve + MINUTE);
  } else {
    dataEnd =
      Math.max(now, lastSolve + 2 * MINUTE);
  }

  if (dataEnd <= dataStart) {
    dataEnd = dataStart + 10 * MINUTE;
  }

  const span = dataEnd - dataStart;

  /*
   * Visual padding is separate from data start/end. This keeps the
   * first and last ticks away from the tactical panel border.
   */
  const sidePadding =
    Math.max(
      30 * 1000,
      Math.min(10 * MINUTE, span * 0.035),
    );

  return {
    dataStart,
    dataEnd,
    axisStart: dataStart - sidePadding,
    axisEnd: dataEnd + sidePadding,
    span: span + sidePadding * 2,
  };
}

function labelTime(value, span) {
  const valueDay = dayjs(value);

  if (span <= 12 * HOUR) {
    return valueDay.format("HH:mm");
  }

  if (span <= 3 * DAY) {
    return valueDay.format("MMM D\nHH:mm");
  }

  if (span <= 45 * DAY) {
    return valueDay.format("MMM D");
  }

  return valueDay.format("MMM 'YY");
}

function niceMax(score) {
  if (!Number.isFinite(score) || score <= 0) {
    return 100;
  }

  const target = score * 1.18;

  const magnitude =
    Math.pow(
      10,
      Math.floor(Math.log10(target)),
    );

  const normalized = target / magnitude;

  let multiplier;

  if (normalized <= 1) {
    multiplier = 1;
  } else if (normalized <= 2) {
    multiplier = 2;
  } else if (normalized <= 5) {
    multiplier = 5;
  } else {
    multiplier = 10;
  }

  return multiplier * magnitude;
}

function makeSentinalsOption(mode, detail) {
  /*
   * Start from CTFd's own scoreboard option. This guarantees that
   * Users mode and Teams mode both use CTFd's official cumulative
   * scoring interpretation.
   */
  const option =
    getOption(mode, detail, null);

  const timeline =
    buildTimeline(option);

  if (!timeline) {
    return null;
  }

  let highestScore = 0;

  (option.series || []).forEach(
    (series, index) => {
      const original = (series.data || [])
        .map((point) => {
          if (!Array.isArray(point)) {
            return null;
          }

          const timestamp =
            toMs(point[0]);

          const score =
            Number(point[1]);

          if (
            timestamp === null ||
            !Number.isFinite(score)
          ) {
            return null;
          }

          highestScore =
            Math.max(highestScore, score);

          return [timestamp, score];
        })
        .filter(Boolean)
        .sort((a, b) => a[0] - b[0]);

      if (!original.length) {
        series.data = [];
        return;
      }

      const finalScore =
        original[original.length - 1][1];

      /*
       * Critical behavior:
       *
       * [event/display start, 0]
       * [solve #1, cumulative score]
       * [solve #2, cumulative score]
       * ...
       * [now/event end, final score]
       */
      series.data = [
        [timeline.dataStart, 0],
        ...original,
        [timeline.dataEnd, finalScore],
      ];

      const color =
        COLORS[index % COLORS.length];

      series.type = "line";
      series.step = "end";
      series.smooth = false;
      series.showSymbol = false;
      series.connectNulls = true;
      series.symbol = "circle";
      series.symbolSize = 7;

      series.lineStyle = {
        width: 2.5,
        color,
        shadowBlur: 4,
        shadowColor: color,
      };

      series.itemStyle = {
        color,
        borderColor: "#050505",
        borderWidth: 2,
      };

      series.emphasis = {
        focus: "series",
        lineStyle: {
          width: 3.2,
        },
      };
    },
  );

  /* Remove all stock CTFd graph chrome. */
  option.title = {
    show: false,
  };

  option.toolbox = {
    show: false,
    feature: {},
  };

  option.dataZoom = [];

  option.backgroundColor =
    "transparent";

  option.grid = {
    top: 18,
    right: 36,
    bottom: 56,
    left: 18,
    containLabel: true,
  };

  option.tooltip = {
    trigger: "axis",
    backgroundColor:
      "rgba(5,5,5,.97)",
    borderColor:
      "rgba(127,29,29,.72)",
    borderWidth: 1,
    padding: 12,

    axisPointer: {
      type: "line",
      lineStyle: {
        color:
          "rgba(239,68,68,.38)",
      },
    },

    textStyle: {
      color: "#cbd5e1",
      fontSize: 12,
      fontFamily: "monospace",
    },
  };

  option.legend = {
    ...(option.legend || {}),
    type: "scroll",
    orient: "horizontal",
    left: "center",
    bottom: 0,
    icon: "circle",
    itemWidth: 9,
    itemHeight: 9,

    textStyle: {
      color: "#94a3b8",
      fontSize: 11,
      fontFamily: "monospace",
    },

    pageIconColor: "#ef4444",
    pageIconInactiveColor:
      "#475569",

    pageTextStyle: {
      color: "#64748b",
    },
  };

  /*
   * CTFd's option uses arrays for both axes.
   * Keep that shape exactly.
   */
  option.xAxis = [
    {
      type: "time",
      min: timeline.axisStart,
      max: timeline.axisEnd,
      boundaryGap: false,
      splitNumber: 6,

      axisLine: {
        show: true,
        lineStyle: {
          color: "#475569",
        },
      },

      axisTick: {
        show: true,
        lineStyle: {
          color: "#475569",
        },
      },

      axisLabel: {
        color: "#64748b",
        fontSize: 11,
        margin: 13,
        hideOverlap: true,
        fontFamily: "monospace",

        formatter: value =>
          labelTime(
            value,
            timeline.span,
          ),
      },

      splitLine: {
        show: false,
      },
    },
  ];

  option.yAxis = [
    {
      type: "value",
      min: 0,
      max: niceMax(highestScore),
      splitNumber: 5,

      axisLine: {
        show: true,
        lineStyle: {
          color: "#475569",
        },
      },

      axisTick: {
        show: false,
      },

      axisLabel: {
        color: "#64748b",
        fontSize: 11,
        margin: 12,
        fontFamily: "monospace",
      },

      splitLine: {
        show: true,
        lineStyle: {
          color:
            "rgba(220,38,38,.14)",
          type: "dashed",
        },
      },
    },
  ];

  return option;
}

Alpine.data("ScoreboardDetail", () => ({
  data: {},
  show: false,
  activeBracket: null,

  async update() {
    try {
      this.data =
        await CTFd.pages.scoreboard
          .getScoreboardDetail(
            10,
            this.activeBracket,
          );

      const option =
        makeSentinalsOption(
          CTFd.config.userMode,
          this.data,
        );

      if (
        !option ||
        !option.series.some(
          series =>
            Array.isArray(series.data) &&
            series.data.length,
        )
      ) {
        this.show = false;
        return;
      }

      /*
       * Show the mount element before embed(). CTFd's native embed
       * wrapper then owns ECharts creation/resizing.
       */
      this.show = true;

      await this.$nextTick();

      embed(
        this.$refs.scoregraph,
        option,
      );
    } catch (error) {
      this.show = false;

      console.error(
        "SentinalsPrime scoreboard graph error:",
        error,
      );
    }
  },

  async init() {
    await this.update();

    setInterval(
      () => this.update(),
      UPDATE_INTERVAL,
    );
  },
}));

Alpine.data("ScoreboardList", () => ({
  standings: [],
  brackets: [],
  activeBracket: null,

  async update() {
    this.brackets =
      await CTFd.pages.scoreboard
        .getBrackets(
          CTFd.config.userMode,
        );

    this.standings =
      await CTFd.pages.scoreboard
        .getScoreboard();
  },

  async init() {
    this.$watch(
      "activeBracket",
      value => {
        this.$dispatch(
          "bracket-change",
          value,
        );
      },
    );

    await this.update();

    setInterval(
      () => this.update(),
      UPDATE_INTERVAL,
    );
  },
}));

Alpine.start();
