SentinalsPrime Phase 8 — Notifications + Phase 7 Scoreboard
===========================================================

This is cumulative over Phase 7.

WHAT CHANGED
------------

Notification history page:
- Removes grey Bootstrap cards.
- Tactical black/red list.
- Responsive layout.
- Native CTFd notification HTML and timestamps preserved.

Toast delivery:
- Same native CTFd x-ref="toast".
- Non-blocking upper-right SentinalsPrime toast.
- Does not autohide because CTFd core uses data-bs-autohide=false.
- Closing it still marks the notification as read through CTFd's native handler.

Alert delivery:
- Same native CTFd x-ref="modal".
- Tactical blocking modal.
- Closing/Acknowledge still marks it read through CTFd's native event handler.

Background delivery:
- Background means NO popup by design.
- CTFd already adds it to unread storage/count.
- Phase 8 implements eventBackground so it does not hit a null handler.
- Notification navbar item briefly pulses as a subtle visual cue.
- Notification remains available on /notifications.

Sound:
- CTFd.js uses Howler and plays only when notification.sound == true.
- It plays only in the master tab, avoiding duplicates with multiple tabs.
- Phase 8 does NOT duplicate playback.
- sound_compat.js reports load/play errors in DevTools and prepares audio
  on the user's first pointer/keyboard interaction.
- Modern browser autoplay policy can still block sound before any user
  interaction. That is browser behavior, not a CTFd bug.

IMPORTANT SOUND FILES
---------------------
Your theme was copied from CTFd core, so these should already exist:

  assets/sounds/notification.webm
  assets/sounds/notification.mp3

Your base.html should point eventSounds to:

  /themes/sentinalsprime/static/sounds/notification.webm
  /themes/sentinalsprime/static/sounds/notification.mp3

After yarn build verify:

  ls -lh static/sounds/notification.webm static/sounds/notification.mp3

Direct HTTP tests:

  https://YOUR-DOMAIN/themes/sentinalsprime/static/sounds/notification.webm
  https://YOUR-DOMAIN/themes/sentinalsprime/static/sounds/notification.mp3

If local sound source files are missing, restore them from core:

  mkdir -p assets/sounds
  cp ~/CTFd/CTFd/themes/core/assets/sounds/notification.webm assets/sounds/
  cp ~/CTFd/CTFd/themes/core/assets/sounds/notification.mp3 assets/sounds/

INSTALL
-------
rm -rf /tmp/sp8
mkdir -p /tmp/sp8

unzip /path/to/sentinalsprime-phase8-notifications.zip -d /tmp/sp8

cp -a /tmp/sp8/sentinalsprime-phase8-notifications/. \
  ~/CTFd/CTFd/themes/sentinalsprime/

Keep only one custom SCSS import near the top of assets/scss/main.scss:

  @use "includes/sentinalsprime";

Then clean build:

  cd ~/CTFd/CTFd/themes/sentinalsprime
  rm -rf static
  yarn build

Verify:
  find static -type f | grep sentinals_scoreboard
  ls -lh static/sounds/notification.webm static/sounds/notification.mp3

Restart:
  cd ~/CTFd
  docker compose restart

Browser:
  Ctrl + Shift + R

TEST MATRIX
-----------
From Admin -> Notifications create tests for:

1. Toast + Sound Off
   - Tactical toast appears.
   - Closing marks notification read.

2. Toast + Sound On
   - Same toast + one sound in master tab.

3. Alert + Sound Off
   - Tactical modal appears and is interactive.

4. Alert + Sound On
   - Tactical modal + one sound.

5. Background + Sound Off
   - No popup.
   - Notifications link pulses.
   - Unread counter increases.
   - Entry appears on /notifications.

6. Background + Sound On
   - No popup.
   - Link pulse/counter.
   - Sound plays once in master tab.

AUDIO DIAGNOSTICS
-----------------
Open DevTools Console and run:

  document.documentElement.dataset.spNotificationAudio

Expected states:
  "ready"
  "loaded"
  "playing"

Possible errors:
  "load-error"    -> sound URL/MIME/file issue
  "play-blocked"  -> browser autoplay restriction; click page once and retry

SERVER-SENT EVENTS
------------------
Real-time notifications require CTFd's event stream to be enabled and a
logged-in user. DevTools Network should show the /events connection while
real-time notifications are active.
