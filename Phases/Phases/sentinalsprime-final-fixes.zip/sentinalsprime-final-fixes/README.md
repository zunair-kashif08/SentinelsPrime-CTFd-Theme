SentinalsPrime consolidated fix

This patch:
- Uses ONE custom SCSS file: assets/scss/includes/_sentinalsprime.scss
- Fixes navbar alignment: brand -> Challenges on the left, SYS_STATUS -> auth/logout on the right
- Fixes unclickable Challenge and Settings/Token modals by removing the .sp-main stacking context
- Restores the exact native CTFd ScoreboardDetail ECharts mount pattern
- Keeps the CTF-Platform-styled scoreboard shell/table

Install:
  unzip sentinalsprime-final-fixes.zip -d /tmp/spfix
  cp -a /tmp/spfix/sentinalsprime-final-fixes/. ~/CTFd/CTFd/themes/sentinalsprime/

Then edit assets/scss/main.scss and keep ONLY this custom line near the TOP:
  @use "includes/sentinalsprime";

Remove:
  @use "includes/phase3";

Delete the old phase file if it exists:
  rm -f assets/scss/includes/_phase3.scss

Build:
  cd ~/CTFd/CTFd/themes/sentinalsprime
  yarn build
  cd ~/CTFd
  docker compose restart

Then Ctrl+Shift+R.

If scoreboard remains empty, open DevTools Console and Network and inspect:
  /api/v1/scoreboard
  /api/v1/scoreboard/top/10
because this patch uses CTFd's stock scoreboard.js without a replacement API client.
