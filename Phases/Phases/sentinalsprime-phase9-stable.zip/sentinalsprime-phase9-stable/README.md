SentinalsPrime Phase 9 — Stable build fix
=========================================

This is cumulative over Phase 8 notifications and the custom cumulative scoreboard.

FIX 1 — SCOREBOARD 500
----------------------
Root cause:
CTFd's vite.config.js has an input named:
  scoreboard: assets/js/scoreboard.js

It DOES NOT build:
  assets/js/sentinals_scoreboard.js

Phase 7/8 referenced the latter via Assets.js(), so Flask could not resolve
that entry in Vite's manifest and /scoreboard could return HTTP 500.

Phase 9 puts the custom cumulative graph controller in:
  assets/js/scoreboard.js

and scoreboard.html loads:
  Assets.js("assets/js/scoreboard.js")

No vite.config.js modification is needed.

FIX 2 — NOTIFICATION PAGE LOOKED RAW
------------------------------------
The screenshot proves templates/notifications.html was updated, but the
compiled CSS being served did not contain the Phase 8 notification rules.

Phase 9 keeps all Phase 8 notification CSS and adds:
  :root { --sentinalsprime-build-phase: 9; }

After build you can prove the new CSS exists:
  grep -R -- '--sentinalsprime-build-phase' static --include='*.css'
  grep -R 'sp-notifications-page' static --include='*.css'

Both commands MUST return matches.

INSTALL
-------
rm -rf /tmp/sp9
mkdir -p /tmp/sp9

unzip /path/to/sentinalsprime-phase9-stable.zip -d /tmp/sp9

cp -a /tmp/sp9/sentinalsprime-phase9-stable/. \
  ~/CTFd/CTFd/themes/sentinalsprime/

main.scss:
Keep exactly one custom import near the top:
  @use "includes/sentinalsprime";

Remove any phase3 import.

CLEAN BUILD
-----------
cd ~/CTFd/CTFd/themes/sentinalsprime

rm -rf static

yarn build

DO NOT restart yet if yarn build reports an error. Paste the full error.

VERIFY MANIFEST / CSS BEFORE RESTART
------------------------------------
1. Scoreboard entry exists:
   grep -n '"scoreboard"' static/manifest.json

2. No custom missing entry is referenced:
   grep -R 'sentinals_scoreboard' templates static/manifest.json || true

   Expected: no template/manifest reference is required anymore.

3. Phase 9 CSS really compiled:
   grep -R -- '--sentinalsprime-build-phase' static --include='*.css'

4. Notification CSS really compiled:
   grep -R 'sp-notifications-page' static --include='*.css'

5. Sound files:
   ls -lh static/sounds/notification.webm static/sounds/notification.mp3

Only after all above pass:

  cd ~/CTFd
  docker compose restart

Then hard refresh:
  Ctrl + Shift + R

IF SCOREBOARD STILL RETURNS 500
-------------------------------
Immediately run:
  cd ~/CTFd
  docker compose logs --tail=120 ctfd

If the service is not named "ctfd":
  docker compose ps
  docker compose logs --tail=120

Paste the Python traceback. HTTP 500 is server-side; the traceback will
identify the exact failing template/asset lookup.

IF NOTIFICATION PAGE IS STILL RAW
---------------------------------
In browser DevTools Console run:
  getComputedStyle(
    document.querySelector(".sp-notifications-page")
  ).maxWidth

Expected:
  approximately "1120px"

If that is not true after the grep checks above, the browser/proxy is serving
an older CSS asset and we should inspect the HTML <link> and cache headers.
