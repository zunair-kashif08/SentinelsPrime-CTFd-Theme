import CTFd from "@ctfdio/ctfd-js";

import dayjs from "dayjs";
import advancedFormat from "dayjs/plugin/advancedFormat";

import times from "./theme/times";
import styles from "./theme/styles";
import highlight from "./theme/highlight";

import alerts from "./utils/alerts";
import tooltips from "./utils/tooltips";
import collapse from "./utils/collapse";
import eventAlerts from "./utils/notifications/alerts";
import eventToasts from "./utils/notifications/toasts";
import eventBackground from "./utils/notifications/background";
import eventRead from "./utils/notifications/read";
import notificationSoundCompatibility from "./utils/notifications/sound_compat";

import "./components/language";

dayjs.extend(advancedFormat);

CTFd.init(window.init);

(() => {
  styles();
  times();
  highlight();

  alerts();
  tooltips();
  collapse();

  eventRead();
  eventAlerts();
  eventToasts();
  eventBackground();
  notificationSoundCompatibility();
})();

export default CTFd;
