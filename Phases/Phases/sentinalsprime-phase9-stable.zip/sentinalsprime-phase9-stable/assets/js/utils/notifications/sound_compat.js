import CTFd from "../../index";

export default () => {
  const howl = CTFd.events?.howl;

  if (!howl) {
    document.documentElement.dataset.spNotificationAudio = "unavailable";
    return;
  }

  document.documentElement.dataset.spNotificationAudio = "ready";

  /*
   * Howler/CTFd performs actual playback only when an incoming notification
   * has sound=true. We do NOT manually play here, which avoids duplicate sound.
   * These handlers only make failures observable in DevTools.
   */
  howl.on("load", () => {
    document.documentElement.dataset.spNotificationAudio = "loaded";
  });

  howl.on("loaderror", (id, error) => {
    document.documentElement.dataset.spNotificationAudio = "load-error";
    console.warn(
      "SentinalsPrime notification sound failed to load:",
      error,
      window.init?.eventSounds,
    );
  });

  howl.on("playerror", (id, error) => {
    document.documentElement.dataset.spNotificationAudio = "play-blocked";
    console.warn(
      "SentinalsPrime notification sound playback was blocked. " +
      "Interact with the page once and retry the notification.",
      error,
    );
  });

  howl.on("play", () => {
    document.documentElement.dataset.spNotificationAudio = "playing";
  });

  /*
   * Modern browsers can suspend WebAudio until the user interacts with the
   * page. Howler normally auto-unlocks this; load() on the first interaction
   * gives the browser a clean opportunity to prepare the audio without making
   * an unsolicited sound.
   */
  const prepareAudio = () => {
    try {
      howl.load();
    } catch (error) {
      console.debug("Notification audio preparation skipped:", error);
    }
  };

  window.addEventListener("pointerdown", prepareAudio, {
    once: true,
    passive: true,
  });

  window.addEventListener("keydown", prepareAudio, {
    once: true,
  });
};
