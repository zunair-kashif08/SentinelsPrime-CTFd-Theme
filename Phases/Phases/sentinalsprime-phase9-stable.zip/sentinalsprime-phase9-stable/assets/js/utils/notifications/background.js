import CTFd from "../../index";

export default () => {
  CTFd._functions.events.eventBackground = data => {
    /*
     * CTFd already:
     * - inserts notification into unread storage
     * - updates unread count
     * - broadcasts the count between tabs
     *
     * Background delivery therefore remains non-blocking/no-popup.
     * We add only a subtle tactical pulse to the Notifications nav link.
     */
    const links = [
      ...document.querySelectorAll('a[href*="/notifications"]'),
    ];

    for (const link of links) {
      link.classList.remove("sp-notification-background-pulse");

      // Force reflow so repeated background notifications replay animation.
      void link.offsetWidth;

      link.classList.add("sp-notification-background-pulse");

      window.setTimeout(() => {
        link.classList.remove("sp-notification-background-pulse");
      }, 2200);
    }

    document.dispatchEvent(
      new CustomEvent("sentinalsprime:background-notification", {
        detail: data,
      }),
    );
  };
};
