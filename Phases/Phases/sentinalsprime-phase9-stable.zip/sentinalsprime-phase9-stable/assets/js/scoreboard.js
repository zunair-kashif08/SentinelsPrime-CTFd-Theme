import Alpine from "alpinejs";
import CTFd from "./index";
import * as echarts from "echarts/core";
import { LineChart } from "echarts/charts";
import {
  TooltipComponent,
  GridComponent,
  LegendComponent,
} from "echarts/components";
import { CanvasRenderer } from "echarts/renderers";

echarts.use([
  LineChart,
  TooltipComponent,
  GridComponent,
  LegendComponent,
  CanvasRenderer,
]);

window.Alpine = Alpine;
window.CTFd = CTFd;

const POLL_INTERVAL =
  window.scoreboardUpdateInterval || 300000;

const COLORS = [
  "#ef4444",
  "#3b82f6",
  "#10b981",
  "#f59e0b",
  "#8b5cf6",
  "#ec4899",
  "#06b6d4",
  "#eab308",
  "#84cc16",
  "#14b8a6",
];

const MINUTE = 60 * 1000;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;

function parseTime(value) {
  if (value === null || value === undefined || value === "") {
    return null;
  }

  if (typeof value === "number") {
    return value < 100000000000
      ? value * 1000
      : value;
  }

  const numeric = Number(value);

  if (Number.isFinite(numeric) && String(value).trim() !== "") {
    return numeric < 100000000000
      ? numeric * 1000
      : numeric;
  }

  const parsed = new Date(value).getTime();
  return Number.isFinite(parsed) ? parsed : null;
}

function collectAccounts(detail) {
  return Object.values(detail || {});
}

function buildRawAccounts(detail) {
  return collectAccounts(detail)
    .map((account) => {
      const solves = [...(account.solves || [])]
        .map((solve) => ({
          time: parseTime(solve.date),
          value: Number(solve.value || 0),
        }))
        .filter(
          (solve) =>
            solve.time !== null &&
            Number.isFinite(solve.value),
        )
        .sort((a, b) => a.time - b.time);

      return {
        id: account.id,
        name: account.name,
        solves,
      };
    })
    .filter((account) => account.solves.length);
}

function chooseTimeline(accounts) {
  const allTimes = accounts.flatMap((a) =>
    a.solves.map((s) => s.time),
  );

  if (!allTimes.length) {
    return null;
  }

  const firstSolve = Math.min(...allTimes);
  const lastSolve = Math.max(...allTimes);

  const configuredStart = parseTime(window.init?.start);
  const configuredEnd = parseTime(window.init?.end);
  const now = Date.now();

  /*
   * Always leave visible zero-score space before the first solve.
   * If the configured start is effectively the same moment as the first
   * solve, move the display start earlier so the 0 -> score jump is visible.
   */
  const leadIn = Math.max(
    5 * MINUTE,
    Math.min(30 * MINUTE, Math.max(MINUTE, (lastSolve - firstSolve) * 0.15)),
  );

  let dataStart =
    configuredStart !== null &&
    configuredStart < firstSolve - MINUTE
      ? configuredStart
      : firstSolve - leadIn;

  /*
   * While live, extend to now plus breathing room.
   * Once the CTF has ended, stop at configured end.
   */
  let dataEnd;

  if (configuredEnd !== null && configuredEnd <= now) {
    dataEnd = Math.max(configuredEnd, lastSolve + MINUTE);
  } else {
    dataEnd = Math.max(now, lastSolve + 5 * MINUTE);
  }

  if (dataEnd <= dataStart) {
    dataEnd = dataStart + 10 * MINUTE;
  }

  const visibleSpan = dataEnd - dataStart;

  const sidePadding = Math.max(
    30 * 1000,
    Math.min(15 * MINUTE, visibleSpan * 0.025),
  );

  return {
    dataStart,
    dataEnd,
    axisStart: dataStart - sidePadding,
    axisEnd: dataEnd + sidePadding,
    span: visibleSpan + sidePadding * 2,
  };
}

function formatAxisTime(value, span) {
  const date = new Date(value);

  if (span <= 12 * HOUR) {
    return date.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  if (span <= 3 * DAY) {
    const day = date.toLocaleDateString([], {
      month: "short",
      day: "numeric",
    });
    const time = date.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
    return `${day}\n${time}`;
  }

  if (span <= 45 * DAY) {
    return date.toLocaleDateString([], {
      month: "short",
      day: "numeric",
    });
  }

  return date.toLocaleDateString([], {
    month: "short",
    year: "2-digit",
  });
}

function buildSeries(accounts, timeline) {
  let highestScore = 0;

  const series = accounts.map((account, index) => {
    let cumulative = 0;

    const solvePoints = account.solves.map((solve) => {
      cumulative += solve.value;
      highestScore = Math.max(highestScore, cumulative);
      return [solve.time, cumulative];
    });

    const color = COLORS[index % COLORS.length];

    return {
      name: account.name,
      type: "line",
      step: "end",
      smooth: false,
      showSymbol: false,
      connectNulls: true,
      symbol: "circle",
      symbolSize: 7,

      /*
       * This is the essential CTF timeline:
       *   start at zero
       *   jump at each solve
       *   keep final score flat through current/end time
       */
      data: [
        [timeline.dataStart, 0],
        ...solvePoints,
        [timeline.dataEnd, cumulative],
      ],

      lineStyle: {
        width: 2.5,
        color,
        shadowBlur: 5,
        shadowColor: color,
        opacity: 0.96,
      },

      itemStyle: {
        color,
        borderColor: "#050505",
        borderWidth: 2,
      },

      emphasis: {
        focus: "series",
        lineStyle: {
          width: 3.2,
        },
      },
    };
  });

  return {
    series,
    highestScore,
  };
}

function niceYMax(highest) {
  if (highest <= 0) {
    return 100;
  }

  const target = highest * 1.18;

  const order = Math.pow(
    10,
    Math.floor(Math.log10(target)),
  );

  const normalized = target / order;

  let nice;

  if (normalized <= 1) {
    nice = 1;
  } else if (normalized <= 2) {
    nice = 2;
  } else if (normalized <= 5) {
    nice = 5;
  } else {
    nice = 10;
  }

  return nice * order;
}

function buildChartOption(detail) {
  const accounts = buildRawAccounts(detail);

  if (!accounts.length) {
    return null;
  }

  const timeline = chooseTimeline(accounts);

  if (!timeline) {
    return null;
  }

  const { series, highestScore } =
    buildSeries(accounts, timeline);

  return {
    animationDuration: 450,
    animationEasing: "cubicOut",
    backgroundColor: "transparent",

    color: COLORS,

    tooltip: {
      trigger: "axis",
      backgroundColor: "rgba(5,5,5,.97)",
      borderColor: "rgba(127,29,29,.72)",
      borderWidth: 1,
      padding: 12,

      textStyle: {
        color: "#cbd5e1",
        fontSize: 12,
        fontFamily:
          "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
      },

      axisPointer: {
        type: "line",
        lineStyle: {
          color: "rgba(239,68,68,.38)",
          width: 1,
        },
      },

      valueFormatter: (value) => value,
    },

    legend: {
      type: "scroll",
      orient: "horizontal",
      left: "center",
      bottom: 0,
      icon: "circle",
      itemWidth: 9,
      itemHeight: 9,

      textStyle: {
        color: "#94a3b8",
        fontSize: 11,
        fontFamily:
          "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
      },

      pageIconColor: "#ef4444",
      pageIconInactiveColor: "#475569",

      pageTextStyle: {
        color: "#64748b",
      },

      data: accounts.map((account) => account.name),
    },

    grid: {
      top: 22,
      right: 38,
      bottom: 58,
      left: 20,
      containLabel: true,
    },

    xAxis: {
      type: "time",
      min: timeline.axisStart,
      max: timeline.axisEnd,
      boundaryGap: false,
      splitNumber: 6,

      axisLine: {
        show: true,
        lineStyle: {
          color: "#475569",
        },
      },

      axisTick: {
        show: true,
        lineStyle: {
          color: "#475569",
        },
      },

      axisLabel: {
        color: "#64748b",
        fontSize: 11,
        margin: 13,
        hideOverlap: true,

        fontFamily:
          "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",

        formatter: (value) =>
          formatAxisTime(value, timeline.span),
      },

      splitLine: {
        show: false,
      },
    },

    yAxis: {
      type: "value",
      min: 0,
      max: niceYMax(highestScore),
      splitNumber: 5,

      axisLine: {
        show: true,
        lineStyle: {
          color: "#475569",
        },
      },

      axisTick: {
        show: false,
      },

      axisLabel: {
        color: "#64748b",
        fontSize: 11,
        margin: 12,

        fontFamily:
          "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
      },

      splitLine: {
        show: true,
        lineStyle: {
          color: "rgba(220,38,38,.14)",
          type: "dashed",
        },
      },
    },

    series,
  };
}

Alpine.data("SentinalsScoreboardGraph", () => ({
  detail: {},
  activeBracket: null,
  chart: null,
  show: false,

  async update() {
    this.detail =
      await CTFd.pages.scoreboard.getScoreboardDetail(
        10,
        this.activeBracket,
      );

    const option =
      buildChartOption(this.detail);

    if (!option) {
      this.show = false;

      if (this.chart) {
        this.chart.dispose();
        this.chart = null;
      }

      return;
    }

    this.show = true;

    await this.$nextTick();

    if (this.chart) {
      this.chart.dispose();
    }

    this.chart =
      echarts.init(this.$refs.chart);

    this.chart.setOption(option, true);
  },

  async init() {
    await this.update();

    this._resize = () => {
      if (this.chart) {
        this.chart.resize();
      }
    };

    window.addEventListener(
      "resize",
      this._resize,
    );

    setInterval(() => {
      this.update();
    }, POLL_INTERVAL);
  },
}));

Alpine.data("ScoreboardList", () => ({
  standings: [],
  brackets: [],
  activeBracket: null,

  async update() {
    this.brackets =
      await CTFd.pages.scoreboard.getBrackets(
        CTFd.config.userMode,
      );

    this.standings =
      await CTFd.pages.scoreboard.getScoreboard();
  },

  async init() {
    this.$watch(
      "activeBracket",
      (value) => {
        this.$dispatch(
          "bracket-change",
          value,
        );
      },
    );

    await this.update();

    setInterval(() => {
      this.update();
    }, POLL_INTERVAL);
  },
}));

Alpine.start();
