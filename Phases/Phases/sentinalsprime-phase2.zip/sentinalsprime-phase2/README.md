SentinalsPrime Phase 2

Fixes:
- Native CTFd home page now renders the CTF-Platform Hero design instead of the default CTFd setup/page content.
- Removes default grey jumbotron/header appearance globally.
- Restyles native CTFd forms, tables, tabs and buttons to the red/black theme.
- Keeps ChallengeBoard and Challenge Alpine code native to CTFd; challenge cards get CTF-Platform styling.
- Fixes challenge modal max-height, scrolling and width so it stays on-screen.
- base.html points to /themes/sentinalsprime/static/img/favicon.svg.

IMPORTANT favicon step:
Copy the exact CTF-Platform public/favicon.svg to:
  CTFd/themes/sentinalsprime/static/img/favicon.svg

This patch does not replace CTFd backend/API behavior.
