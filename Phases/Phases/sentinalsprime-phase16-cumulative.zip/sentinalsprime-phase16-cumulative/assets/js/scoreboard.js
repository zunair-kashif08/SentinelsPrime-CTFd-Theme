import Alpine from "alpinejs";
import CTFd from "./index";
import dayjs from "dayjs";

import { getOption } from "./utils/graphs/echarts/scoreboard";
import { embed } from "./utils/graphs/echarts";

window.Alpine = Alpine;
window.CTFd = CTFd;

const UPDATE_INTERVAL =
  window.scoreboardUpdateInterval || 300000;

const MINUTE = 60 * 1000;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;

const COLORS = [
  "#ef4444",
  "#3b82f6",
  "#10b981",
  "#f59e0b",
  "#8b5cf6",
  "#ec4899",
  "#06b6d4",
  "#eab308",
  "#84cc16",
  "#14b8a6",
];

function toMs(value) {
  if (value instanceof Date) {
    return value.getTime();
  }

  if (typeof value === "number") {
    return value < 100000000000
      ? value * 1000
      : value;
  }

  const parsed = dayjs(value);

  return parsed.isValid()
    ? parsed.valueOf()
    : null;
}

function configuredTime(value) {
  if (
    value === undefined ||
    value === null ||
    value === ""
  ) {
    return null;
  }

  if (typeof value === "number") {
    return value < 100000000000
      ? value * 1000
      : value;
  }

  const numeric = Number(value);

  if (
    Number.isFinite(numeric) &&
    String(value).trim() !== ""
  ) {
    return numeric < 100000000000
      ? numeric * 1000
      : numeric;
  }

  const parsed = dayjs(value);

  return parsed.isValid()
    ? parsed.valueOf()
    : null;
}

function collectTimes(option) {
  const times = [];

  for (const series of option.series || []) {
    for (const point of series.data || []) {
      if (!Array.isArray(point)) {
        continue;
      }

      const ms = toMs(point[0]);

      if (ms !== null) {
        times.push(ms);
      }
    }
  }

  return times;
}

function buildTimeline(option) {
  const solveTimes = collectTimes(option);

  if (!solveTimes.length) {
    return null;
  }

  const firstSolve = Math.min(...solveTimes);
  const lastSolve = Math.max(...solveTimes);

  const eventStart =
    configuredTime(window.init?.start);

  const eventEnd =
    configuredTime(window.init?.end);

  const now = Date.now();

  /*
   * If the configured start is meaningfully before the first solve,
   * use it. Otherwise create a short zero-score lead-in so the initial
   * score jump is visible.
   */
  const naturalSpan =
    Math.max(lastSolve - firstSolve, 5 * MINUTE);

  const leadIn =
    Math.max(
      2 * MINUTE,
      Math.min(20 * MINUTE, naturalSpan * 0.18),
    );

  let dataStart;

  if (
    eventStart !== null &&
    eventStart < firstSolve - MINUTE
  ) {
    dataStart = eventStart;
  } else {
    dataStart = firstSolve - leadIn;
  }

  /*
   * While the event is live, extend the final score line to now.
   * If the configured event has ended, stop at its end time.
   */
  let dataEnd;

  if (
    eventEnd !== null &&
    eventEnd <= now
  ) {
    dataEnd =
      Math.max(eventEnd, lastSolve + MINUTE);
  } else {
    dataEnd =
      Math.max(now, lastSolve + 2 * MINUTE);
  }

  if (dataEnd <= dataStart) {
    dataEnd = dataStart + 10 * MINUTE;
  }

  const span = dataEnd - dataStart;

  /*
   * Visual padding is separate from data start/end. This keeps the
   * first and last ticks away from the tactical panel border.
   */
  const sidePadding =
    Math.max(
      30 * 1000,
      Math.min(10 * MINUTE, span * 0.035),
    );

  return {
    dataStart,
    dataEnd,
    axisStart: dataStart - sidePadding,
    axisEnd: dataEnd + sidePadding,
    span: span + sidePadding * 2,
  };
}

function labelTime(value, span) {
  const valueDay = dayjs(value);

  if (span <= 12 * HOUR) {
    return valueDay.format("HH:mm");
  }

  if (span <= 3 * DAY) {
    return valueDay.format("MMM D\nHH:mm");
  }

  if (span <= 45 * DAY) {
    return valueDay.format("MMM D");
  }

  return valueDay.format("MMM 'YY");
}

function niceMax(score) {
  if (!Number.isFinite(score) || score <= 0) {
    return 100;
  }

  const target = score * 1.18;

  const magnitude =
    Math.pow(
      10,
      Math.floor(Math.log10(target)),
    );

  const normalized = target / magnitude;

  let multiplier;

  if (normalized <= 1) {
    multiplier = 1;
  } else if (normalized <= 2) {
    multiplier = 2;
  } else if (normalized <= 5) {
    multiplier = 5;
  } else {
    multiplier = 10;
  }

  return multiplier * magnitude;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function getTooltipTimestamp(params) {
  const rows =
    Array.isArray(params)
      ? params
      : [params];

  if (!rows.length || !rows[0]) {
    return null;
  }

  const axisValue = rows[0].axisValue;
  const axisTimestamp = toMs(axisValue);

  if (axisTimestamp !== null) {
    return axisTimestamp;
  }

  if (
    Array.isArray(rows[0].value) &&
    rows[0].value.length >= 1
  ) {
    return toMs(rows[0].value[0]);
  }

  return null;
}

function scoreAtTimestamp(series, timestamp) {
  let score = 0;

  const points =
    (series.data || [])
      .map(point => {
        if (
          !Array.isArray(point) ||
          point.length < 2
        ) {
          return null;
        }

        const time = toMs(point[0]);
        const value = Number(point[1]);

        if (
          time === null ||
          !Number.isFinite(value)
        ) {
          return null;
        }

        return [time, value];
      })
      .filter(Boolean)
      .sort((a, b) => a[0] - b[0]);

  for (const point of points) {
    if (point[0] > timestamp) {
      break;
    }

    score = point[1];
  }

  return score;
}

function formatTooltip(params, allSeries) {
  const timestamp =
    getTooltipTimestamp(params);

  if (timestamp === null) {
    return "";
  }

  const timeLabel =
    dayjs(timestamp).format(
      "MMM D, YYYY • HH:mm:ss",
    );

  /*
   * ECharts only supplies the series that have an actual data point at the
   * current axis position. On a step chart that meant hovering user1's solve
   * displayed user1 only, even though Test was already sitting at 100.
   *
   * Calculate the cumulative value of EVERY visible series at this timestamp
   * from its step data instead.
   */
  const accounts =
    (allSeries || [])
      .filter(
        series =>
          Array.isArray(series.data) &&
          series.data.length,
      )
      .map((series, index) => ({
        name: series.name || `Series ${index + 1}`,
        score: scoreAtTimestamp(
          series,
          timestamp,
        ),
        color:
          series.lineStyle?.color ||
          series.itemStyle?.color ||
          COLORS[index % COLORS.length],
      }))
      .sort((a, b) =>
        b.score - a.score ||
        String(a.name).localeCompare(String(b.name)),
      );

  const rows =
    accounts
      .map(account => `
        <div style="
          display:flex;
          align-items:center;
          gap:9px;
          min-width:205px;
          padding:4px 0;
        ">
          <span style="
            width:8px;
            height:8px;
            flex:0 0 8px;
            border-radius:999px;
            background:${account.color};
            box-shadow:0 0 7px ${account.color};
          "></span>

          <span style="
            min-width:0;
            flex:1 1 auto;
            overflow:hidden;
            color:#cbd5e1;
            font-weight:700;
            text-overflow:ellipsis;
            white-space:nowrap;
          ">
            ${escapeHtml(account.name)}
          </span>

          <strong style="
            margin-left:14px;
            color:#f8fafc;
            font-weight:800;
            white-space:nowrap;
          ">
            ${account.score} pts
          </strong>
        </div>
      `)
      .join("");

  return `
    <div style="
      min-width:235px;
      max-width:340px;
      font-family:
        ui-monospace,
        SFMono-Regular,
        Menlo,
        Monaco,
        Consolas,
        monospace;
    ">
      <div style="
        margin-bottom:8px;
        padding-bottom:8px;
        border-bottom:
          1px solid rgba(127,29,29,.48);
        color:#94a3b8;
        font-size:11px;
        font-weight:700;
        letter-spacing:.04em;
        white-space:nowrap;
      ">
        ${escapeHtml(timeLabel)}
      </div>

      ${rows}
    </div>
  `;
}

function makeSentinalsOption(mode, detail) {
  /*
   * Start from CTFd's own scoreboard option. This guarantees that
   * Users mode and Teams mode both use CTFd's official cumulative
   * scoring interpretation.
   */
  const option =
    getOption(mode, detail, null);

  const timeline =
    buildTimeline(option);

  if (!timeline) {
    return null;
  }

  let highestScore = 0;

  (option.series || []).forEach(
    (series, index) => {
      const original = (series.data || [])
        .map((point) => {
          if (!Array.isArray(point)) {
            return null;
          }

          const timestamp =
            toMs(point[0]);

          const score =
            Number(point[1]);

          if (
            timestamp === null ||
            !Number.isFinite(score)
          ) {
            return null;
          }

          highestScore =
            Math.max(highestScore, score);

          return [timestamp, score];
        })
        .filter(Boolean)
        .sort((a, b) => a[0] - b[0]);

      if (!original.length) {
        series.data = [];
        return;
      }

      const finalScore =
        original[original.length - 1][1];

      /*
       * Critical behavior:
       *
       * [event/display start, 0]
       * [solve #1, cumulative score]
       * [solve #2, cumulative score]
       * ...
       * [now/event end, final score]
       */
      series.data = [
        [timeline.dataStart, 0],
        ...original,
        [timeline.dataEnd, finalScore],
      ];

      const color =
        COLORS[index % COLORS.length];

      series.type = "line";
      series.step = "end";
      series.smooth = false;
      series.showSymbol = false;
      series.connectNulls = true;
      // ECharts >= 5.2: make the actual polyline participate in mouse events.
      series.triggerLineEvent = true;
      series.silent = false;
      series.symbol = "circle";
      series.symbolSize = 7;

      series.lineStyle = {
        width: 2.5,
        color,
        shadowBlur: 4,
        shadowColor: color,
      };

      series.itemStyle = {
        color,
        borderColor: "#050505",
        borderWidth: 2,
      };

      series.emphasis = {
        focus: "series",
        lineStyle: {
          width: 3.2,
        },
      };
    },
  );

  /* Remove all stock CTFd graph chrome. */
  option.title = {
    show: false,
  };

  option.toolbox = {
    show: false,
    feature: {},
  };

  option.dataZoom = [];

  option.backgroundColor =
    "transparent";

  option.grid = {
    top: 18,
    right: 36,
    bottom: 56,
    left: 18,
    containLabel: true,
  };

  option.tooltip = {
    trigger: "axis",
    triggerOn: "mousemove|click",
    confine: true,
    appendToBody: false,
    enterable: false,
    transitionDuration: 0.12,

    backgroundColor:
      "rgba(5,5,5,.975)",

    borderColor:
      "rgba(127,29,29,.78)",

    borderWidth: 1,
    padding: 12,

    axisPointer: {
      type: "line",
      snap: false,
      triggerTooltip: true,
      animation: false,

      lineStyle: {
        color:
          "rgba(239,68,68,.42)",
        width: 1,
        type: "dashed",
      },
    },

    textStyle: {
      color: "#cbd5e1",
      fontSize: 12,
      fontFamily: "monospace",
    },

    extraCssText:
      "width:auto;" +
      "height:auto;" +
      "max-width:340px;" +
      "box-shadow:0 16px 45px rgba(0,0,0,.62)," +
      "0 0 18px rgba(220,38,38,.08);" +
      "border-radius:0;" +
      "backdrop-filter:blur(10px);",

    formatter: params =>
      formatTooltip(params, option.series),
  };

  option.legend = {
    ...(option.legend || {}),
    type: "scroll",
    orient: "horizontal",
    left: "center",
    bottom: 0,
    icon: "circle",
    itemWidth: 9,
    itemHeight: 9,

    textStyle: {
      color: "#94a3b8",
      fontSize: 11,
      fontFamily: "monospace",
    },

    pageIconColor: "#ef4444",
    pageIconInactiveColor:
      "#475569",

    pageTextStyle: {
      color: "#64748b",
    },
  };

  /*
   * CTFd's option uses arrays for both axes.
   * Keep that shape exactly.
   */
  option.xAxis = [
    {
      type: "time",
      min: timeline.axisStart,
      max: timeline.axisEnd,
      boundaryGap: false,
      splitNumber: 6,

      axisLine: {
        show: true,
        lineStyle: {
          color: "#475569",
        },
      },

      axisTick: {
        show: true,
        lineStyle: {
          color: "#475569",
        },
      },

      axisLabel: {
        color: "#64748b",
        fontSize: 11,
        margin: 13,
        hideOverlap: true,
        fontFamily: "monospace",

        formatter: value =>
          labelTime(
            value,
            timeline.span,
          ),
      },

      splitLine: {
        show: false,
      },

      axisPointer: {
        show: true,
        snap: false,
        triggerTooltip: true,
        animation: false,
        lineStyle: {
          color: "rgba(239,68,68,.42)",
          width: 1,
          type: "dashed",
        },
      },
    },
  ];

  option.yAxis = [
    {
      type: "value",
      min: 0,
      max: niceMax(highestScore),
      splitNumber: 5,

      axisLine: {
        show: true,
        lineStyle: {
          color: "#475569",
        },
      },

      axisTick: {
        show: false,
      },

      axisLabel: {
        color: "#64748b",
        fontSize: 11,
        margin: 12,
        fontFamily: "monospace",
      },

      splitLine: {
        show: true,
        lineStyle: {
          color:
            "rgba(220,38,38,.14)",
          type: "dashed",
        },
      },
    },
  ];

  return option;
}

Alpine.data("ScoreboardDetail", () => ({
  data: {},
  show: false,
  activeBracket: null,

  async update() {
    try {
      this.data =
        await CTFd.pages.scoreboard
          .getScoreboardDetail(
            10,
            this.activeBracket,
          );

      const option =
        makeSentinalsOption(
          CTFd.config.userMode,
          this.data,
        );

      if (
        !option ||
        !option.series.some(
          series =>
            Array.isArray(series.data) &&
            series.data.length,
        )
      ) {
        this.show = false;
        return;
      }

      /*
       * Show the mount element before embed(). CTFd's native embed
       * wrapper then owns ECharts creation/resizing.
       */
      this.show = true;

      await this.$nextTick();

      embed(
        this.$refs.scoregraph,
        option,
      );
    } catch (error) {
      this.show = false;

      console.error(
        "SentinalsPrime scoreboard graph error:",
        error,
      );
    }
  },

  async init() {
    await this.update();

    setInterval(
      () => this.update(),
      UPDATE_INTERVAL,
    );
  },
}));

Alpine.data("ScoreboardList", () => ({
  standings: [],
  brackets: [],
  activeBracket: null,

  async update() {
    this.brackets =
      await CTFd.pages.scoreboard
        .getBrackets(
          CTFd.config.userMode,
        );

    this.standings =
      await CTFd.pages.scoreboard
        .getScoreboard();
  },

  async init() {
    this.$watch(
      "activeBracket",
      value => {
        this.$dispatch(
          "bracket-change",
          value,
        );
      },
    );

    await this.update();

    setInterval(
      () => this.update(),
      UPDATE_INTERVAL,
    );
  },
}));

Alpine.start();
