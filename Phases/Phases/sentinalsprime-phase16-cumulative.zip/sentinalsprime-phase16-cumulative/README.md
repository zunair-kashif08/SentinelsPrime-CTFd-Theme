SentinalsPrime Phase 16 — CUMULATIVE
====================================

Includes everything from Phase 15 plus the scoreboard table alignment fix.

FIX
---
The SCORE heading and numeric score cells were not visually aligned because
HTML table auto-layout was free to size the columns based on their contents.

Phase 16 gives the scoreboard an explicit 3-column structure:

  PLACE      USER / TEAM                         SCORE
  fixed      flexible                            fixed

Desktop:
  Place = 120px
  Account = remaining width
  Score = 180px

Mobile:
  Place = 78px
  Score = 118px

Both SCORE and every numeric value now use the same `.sp-score-heading` /
`.sp-score-value` geometry and right padding, so they share exactly the same
right alignment line.

INSTALL
-------
rm -rf /tmp/sp16
mkdir -p /tmp/sp16

unzip /path/to/sentinalsprime-phase16-cumulative.zip -d /tmp/sp16

cp -a /tmp/sp16/sentinalsprime-phase16-cumulative/. \
  ~/CTFd/CTFd/themes/sentinalsprime/

Keep one custom SCSS import near the top of assets/scss/main.scss:

  @use "includes/sentinalsprime";

Clean build:

  cd ~/CTFd/CTFd/themes/sentinalsprime
  rm -rf static
  yarn build

Verify:

  grep -R -- '--sentinalsprime-build-phase: 16' \
    static --include='*.css'

Restart:

  cd ~/CTFd
  docker compose restart

Then hard refresh:
  Ctrl + Shift + R
