import Alpine from "alpinejs";
import CTFd from "./index";
import * as echarts from "echarts/core";
import { LineChart } from "echarts/charts";
import {
  TooltipComponent,
  GridComponent,
  LegendComponent,
} from "echarts/components";
import { CanvasRenderer } from "echarts/renderers";

echarts.use([
  LineChart,
  TooltipComponent,
  GridComponent,
  LegendComponent,
  CanvasRenderer,
]);

window.Alpine = Alpine;
window.CTFd = CTFd;

const COLORS = [
  "#ef4444",
  "#3b82f6",
  "#10b981",
  "#f59e0b",
  "#8b5cf6",
  "#ec4899",
  "#06b6d4",
  "#eab308",
  "#84cc16",
  "#14b8a6",
];

const scoreboardUpdateInterval =
  window.scoreboardUpdateInterval || 300000;

function cumulativeSeries(account, index) {
  let score = 0;
  return (account.solves || []).map((solve) => {
    score += Number(solve.value || 0);
    return [new Date(solve.date).getTime(), score];
  }).map((point, pointIndex, points) => {
    // ECharts' step:'end' gives the same stepAfter feel as the React version.
    return point;
  });
}

function createChartOption(mode, detail) {
  const accounts = Object.values(detail || {});
  const series = accounts.map((account, index) => ({
    name: account.name,
    type: "line",
    step: "end",
    showSymbol: false,
    symbol: "circle",
    symbolSize: 7,
    lineStyle: {
      width: 2,
      color: COLORS[index % COLORS.length],
    },
    itemStyle: {
      color: COLORS[index % COLORS.length],
      borderColor: "#050505",
      borderWidth: 2,
    },
    emphasis: {
      focus: "series",
      scale: 1.2,
    },
    data: cumulativeSeries(account, index),
  }));

  return {
    animation: true,
    backgroundColor: "transparent",
    color: COLORS,
    tooltip: {
      trigger: "axis",
      backgroundColor: "rgba(5,5,5,.95)",
      borderColor: "rgba(127,29,29,.5)",
      borderWidth: 1,
      padding: 12,
      textStyle: {
        color: "#cbd5e1",
        fontSize: 12,
        fontFamily: "monospace",
      },
      axisPointer: {
        type: "line",
        lineStyle: {
          color: "rgba(239,68,68,.30)",
        },
      },
    },
    legend: {
      type: "scroll",
      bottom: 0,
      icon: "circle",
      itemWidth: 8,
      itemHeight: 8,
      textStyle: {
        color: "#94a3b8",
        fontSize: 11,
        fontFamily: "monospace",
      },
      data: accounts.map((account) => account.name),
    },
    grid: {
      top: 20,
      right: 30,
      bottom: 55,
      left: 10,
      containLabel: true,
    },
    xAxis: {
      type: "time",
      boundaryGap: false,
      axisLine: {
        lineStyle: { color: "#475569" },
      },
      axisTick: {
        lineStyle: { color: "#475569" },
      },
      axisLabel: {
        color: "#64748b",
        fontSize: 11,
        fontFamily: "monospace",
        margin: 12,
        formatter: (value) =>
          new Date(value).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          }),
      },
      splitLine: { show: false },
    },
    yAxis: {
      type: "value",
      min: 0,
      axisLine: {
        show: true,
        lineStyle: { color: "#475569" },
      },
      axisTick: { show: false },
      axisLabel: {
        color: "#64748b",
        fontSize: 11,
        fontFamily: "monospace",
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "rgba(220,38,38,.15)",
          type: "dashed",
        },
      },
    },
    // Intentionally no CTFd stock toolbox/dataZoom slider.
    series,
  };
}

Alpine.data("SentinalsScoreboard", () => ({
  standings: [],
  brackets: [],
  detail: {},
  activeBracket: null,
  loading: true,
  chart: null,

  get filteredStandings() {
    if (!this.activeBracket) {
      return this.standings;
    }
    return this.standings.filter(
      (standing) => standing.bracket_id === this.activeBracket,
    );
  },

  async load() {
    this.loading = true;

    try {
      const [standings, brackets, detail] = await Promise.all([
        CTFd.pages.scoreboard.getScoreboard(),
        CTFd.pages.scoreboard.getBrackets(CTFd.config.userMode),
        CTFd.pages.scoreboard.getScoreboardDetail(
          10,
          this.activeBracket,
        ),
      ]);

      this.standings = standings || [];
      this.brackets = brackets || [];
      this.detail = detail || {};

      this.$nextTick(() => this.renderChart());
    } catch (error) {
      console.error("SentinalsPrime scoreboard load failed:", error);
      this.standings = [];
      this.detail = {};
      this.disposeChart();
    } finally {
      this.loading = false;
    }
  },

  setBracket(id) {
    this.activeBracket = id;
    this.load();
  },

  disposeChart() {
    if (this.chart) {
      this.chart.dispose();
      this.chart = null;
    }
  },

  renderChart() {
    const target = this.$refs.chart;
    if (!target) {
      return;
    }

    this.disposeChart();

    if (!Object.keys(this.detail || {}).length) {
      return;
    }

    this.chart = echarts.init(target);
    this.chart.setOption(
      createChartOption(CTFd.config.userMode, this.detail),
      true,
    );
  },

  init() {
    this.load();

    this._resizeHandler = () => {
      if (this.chart) {
        this.chart.resize();
      }
    };
    window.addEventListener("resize", this._resizeHandler);

    this._timer = setInterval(
      () => this.load(),
      scoreboardUpdateInterval,
    );
  },
}));

Alpine.start();
