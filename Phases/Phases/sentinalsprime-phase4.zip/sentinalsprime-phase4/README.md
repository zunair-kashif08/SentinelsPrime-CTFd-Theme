SentinalsPrime Phase 4
======================

This patch fixes the exact modal issue shown in the screen recording and
replaces the CTFd-looking scoreboard with the CTF-Platform visual design.

ROOT CAUSE OF THE MODAL BUG
---------------------------
The modal backdrop is appended to <body> by Bootstrap. SentinalsPrime had:

  .sp-main .container { position: relative; z-index: 2; }
  .sp-page-shell      { position: relative; z-index: 2; }

Those wrappers created stacking contexts. The challenge modal is inside
.sp-page-shell and Settings/Token modals are inside .container. Therefore
their own z-index could not place them above the body-level backdrop.

Phase 4 resets those wrappers to z-index:auto and keeps the actual Bootstrap
modal at 1060 / backdrop at 1050.

SCOREBOARD
----------
The old scoreboard used CTFd's stock getOption(), which always adds its
toolbox and dataZoom slider. Phase 4 replaces assets/js/scoreboard.js with
a native Alpine + CTFd.js + ECharts controller.

It still calls CTFd's native:
  CTFd.pages.scoreboard.getScoreboard()
  CTFd.pages.scoreboard.getBrackets()
  CTFd.pages.scoreboard.getScoreboardDetail()

No React. No duplicate backend. No custom scoring API.

INSTALL
-------
rm -rf /tmp/sp4
mkdir -p /tmp/sp4
unzip /path/to/sentinalsprime-phase4.zip -d /tmp/sp4

cp -a /tmp/sp4/sentinalsprime-phase4/. \
  ~/CTFd/CTFd/themes/sentinalsprime/

There is ONE custom SCSS file:
  assets/scss/includes/_sentinalsprime.scss

assets/scss/main.scss should contain ONLY:
  @use "includes/sentinalsprime";

Remove any:
  @use "includes/phase3";

Delete:
  rm -f assets/scss/includes/_phase3.scss

Then:
  cd ~/CTFd/CTFd/themes/sentinalsprime
  yarn build

  cd ~/CTFd
  docker compose restart

Hard refresh:
  Ctrl + Shift + R
