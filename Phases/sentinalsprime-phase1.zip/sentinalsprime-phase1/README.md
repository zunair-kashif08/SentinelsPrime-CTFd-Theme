# SentinalsPrime CTFd native-theme conversion — Phase 1

This is an overlay patch for the current CTFd `core` theme, not a standalone complete theme yet.

## Apply
1. Copy the current CTFd core theme to a new theme folder:
   `cp -a CTFd/themes/core CTFd/themes/sentinalsprime`
2. Copy the files from this patch into `CTFd/themes/sentinalsprime/`, preserving paths.
3. In `CTFd/themes/sentinalsprime/assets/scss/main.scss`, add this as the final `@use` line:
   `@use "includes/sentinalsprime";`
4. From the `sentinalsprime` theme folder run `yarn install` and then `yarn dev` while developing, or `yarn build` for production.
5. Select `sentinalsprime` in the CTFd admin theme setting.

## What Phase 1 converts
- global cinematic red glow
- exact 40px hex-grid background
- original SentinalsPrime logo SVG
- native CTFd navbar routing/auth state instead of React auth polling
- original login visual design using CTFd LoginForm + nonce
- original scrollbar + Markdown styling
- original footer
- CSS replacements for React/Tailwind motion on these elements

## Important
Do not overwrite CTFd admin templates. This patch only targets the public theme.
