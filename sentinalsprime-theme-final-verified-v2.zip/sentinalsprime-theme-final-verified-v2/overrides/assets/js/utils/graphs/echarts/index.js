import * as echarts from "echarts/core";
import { LineChart } from "echarts/charts";
import {
  TitleComponent,
  TooltipComponent,
  GridComponent,
  DatasetComponent,
  TransformComponent,
  LegendComponent,
  ToolboxComponent,
  DataZoomComponent,
} from "echarts/components";
import { LabelLayout, UniversalTransition } from "echarts/features";
import { CanvasRenderer } from "echarts/renderers";

echarts.use([
  LineChart,
  TitleComponent,
  TooltipComponent,
  GridComponent,
  DatasetComponent,
  TransformComponent,
  LegendComponent,
  ToolboxComponent,
  DataZoomComponent,
  LabelLayout,
  UniversalTransition,
  CanvasRenderer,
]);

export function embed(target, option) {
  const old = echarts.getInstanceByDom(target);

  if (old) {
    old.dispose();
  }

  const chart = echarts.init(target);
  chart.setOption(option, true);

  const resize = () => {
    if (!chart.isDisposed()) {
      chart.resize();
    }
  };

  window.addEventListener("resize", resize);

  // Existing CTFd callers may ignore this. SentinalsPrime scoreboard uses it
  // to distinguish direct-series hover from normal axis hover.
  return chart;
}
