#!/usr/bin/env bash
set -euo pipefail
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CTFD_ROOT="${1:-$HOME/CTFd}"
DEST="$CTFD_ROOT/CTFd/themes/sentinalsprime"
[[ -d "$DEST" ]] || { echo "ERROR: theme not found: $DEST" >&2; exit 1; }
cp -a "$SELF_DIR/overrides/." "$DEST/"
MAIN="$DEST/assets/scss/main.scss"
python3 - "$MAIN" <<'PY2'
from pathlib import Path
import sys
p=Path(sys.argv[1])
text=p.read_text()
lines=[ln for ln in text.splitlines() if '@use "includes/sentinalsprime"' not in ln and '@use "includes/phase3"' not in ln]
p.write_text('@use "includes/sentinalsprime";\n'+'\n'.join(lines)+'\n')
PY2
cd "$DEST"
rm -rf static
yarn build
"$SELF_DIR/verify.sh" "$DEST"
echo "Updated verified SentinalsPrime theme: $DEST"
