#!/usr/bin/env bash
set -euo pipefail
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CTFD_ROOT="${1:-$HOME/CTFd}"
OUT="${2:-$PWD/sentinalsprime}"
CORE="$CTFD_ROOT/CTFd/themes/core"
[[ -d "$CORE" ]] || { echo "ERROR: core theme not found: $CORE" >&2; exit 1; }
rm -rf "$OUT"
cp -a "$CORE" "$OUT"
cp -a "$SELF_DIR/overrides/." "$OUT/"
MAIN="$OUT/assets/scss/main.scss"
python3 - "$MAIN" <<'PY2'
from pathlib import Path
import sys
p=Path(sys.argv[1]); text=p.read_text()
lines=[ln for ln in text.splitlines() if '@use "includes/sentinalsprime"' not in ln and '@use "includes/phase3"' not in ln]
p.write_text('@use "includes/sentinalsprime";\n'+'\n'.join(lines)+'\n')
PY2
echo "Materialized complete theme source at: $OUT"
