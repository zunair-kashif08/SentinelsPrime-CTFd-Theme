# SentinalsPrime final-theme audit

This package was rebuilt after comparing the user-supplied phase archives. The latest cumulative source is Phase 18. Files that stopped appearing in later cumulative archives were traced back to the latest phase that actually modified them.

## Final source mapping

| Final file | Source used |
|---|---|
| `assets/img/apple-touch-icon.png` | Phase 5 / later favicon compatibility pass |
| `assets/img/favicon-32x32.png` | Phase 5 / later favicon compatibility pass |
| `assets/img/favicon.ico` | Phase 5 / later favicon compatibility pass |
| `assets/img/favicon.png` | Phase 5 / later favicon compatibility pass |
| `assets/img/favicon.svg` | Phase 5 / later favicon compatibility pass |
| `assets/js/index.js` | Phase 18 cumulative (exact bytes) |
| `assets/js/scoreboard.js` | Phase 18 cumulative (exact bytes) |
| `assets/js/utils/graphs/echarts/index.js` | Phase 18 cumulative (exact bytes) |
| `assets/js/utils/notifications/background.js` | Phase 18 cumulative (exact bytes) |
| `assets/js/utils/notifications/sound_compat.js` | Phase 18 cumulative (exact bytes) |
| `assets/scss/includes/_sentinalsprime.scss` | Phase 18 cumulative (exact bytes) |
| `templates/base.html` | Phase 5 + later title/favicon compatibility pass |
| `templates/challenges.html` | Phase 5 |
| `templates/components/navbar.html` | Phase 1 / final-fixes (identical) |
| `templates/components/notifications.html` | Phase 18 cumulative (exact bytes) |
| `templates/components/snackbar.html` | Phase 18 cumulative (exact bytes) |
| `templates/login.html` | Phase 1 |
| `templates/notifications.html` | Phase 18 cumulative (exact bytes) |
| `templates/page.html` | Phase 2 |
| `templates/scoreboard.html` | Phase 18 cumulative (exact bytes) |

## Intentionally excluded obsolete files

- `assets/scss/includes/_phase3.scss` — superseded by the single consolidated `_sentinalsprime.scss`.
- `assets/js/sentinals_scoreboard.js` — obsolete Phase 8 experimental entry; the final scoreboard correctly uses CTFd's existing `assets/js/scoreboard.js` Vite entry.

## Verification results

- [x] phase18 exact: assets/scss/includes/_sentinalsprime.scss
- [x] phase18 exact: assets/js/utils/graphs/echarts/index.js
- [x] phase18 exact: assets/js/utils/notifications/sound_compat.js
- [x] phase18 exact: assets/js/utils/notifications/background.js
- [x] phase18 exact: assets/js/index.js
- [x] phase18 exact: assets/js/scoreboard.js
- [x] phase18 exact: templates/scoreboard.html
- [x] phase18 exact: templates/notifications.html
- [x] phase18 exact: templates/components/notifications.html
- [x] phase18 exact: templates/components/snackbar.html
- [x] early exact: templates/login.html
- [x] early exact: templates/components/navbar.html
- [x] early exact: templates/page.html
- [x] early exact: templates/challenges.html
- [x] phase18 build marker
- [x] no phase3 import file bundled
- [x] no obsolete sentinals_scoreboard.js bundled
- [x] scoreboard uses native Vite entry
- [x] scoreboard no obsolete custom entry
- [x] scoreboard direct line hover logic present
- [x] scoreboard cumulative logic present
- [x] scoreboard embed wrapper present
- [x] notification background handler present
- [x] notification sound compatibility present
- [x] base custom titles present
- [x] base ICO favicon present
- [x] base Apple favicon present
- [x] challenge template custom board present
- [x] navbar custom brand present

## Phase archives reviewed

- `sentinalsprime-final-fixes(1).zip`
- `sentinalsprime-phase1(1).zip`
- `sentinalsprime-phase2(1).zip`
- `sentinalsprime-phase3(1).zip`
- `sentinalsprime-phase4(1).zip`
- `sentinalsprime-phase5(1).zip`
- `sentinalsprime-phase6-scoreboard(1).zip`
- `sentinalsprime-phase8-notifications(1).zip`
- `sentinalsprime-phase9-stable(1).zip`
- `sentinalsprime-phase11-cumulative(1).zip`
- `sentinalsprime-phase13-cumulative(1).zip`
- `sentinalsprime-phase16-cumulative(1).zip`
- `sentinalsprime-phase17-cumulative(1).zip`
- `sentinalsprime-phase18-cumulative(1).zip`

## Important portability note

This archive stores every **SentinalsPrime customization** in one place. The installer creates a complete theme by copying the `core` theme from the target CTFd installation first, then overlaying these final files. This is deliberate: it keeps untouched CTFd core files matched to the CTFd version you install on, instead of freezing unrelated core files from one version. CTFd also supports theme fallback, but building from the local core tree is the safest way to preserve Vite source imports and page compatibility.
