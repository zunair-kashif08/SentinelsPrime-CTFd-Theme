#!/usr/bin/env bash
set -euo pipefail
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CTFD_ROOT="${1:-$HOME/CTFd}"
CORE="$CTFD_ROOT/CTFd/themes/core"
DEST="$CTFD_ROOT/CTFd/themes/sentinalsprime"

[[ -d "$CORE" ]] || { echo "ERROR: core theme not found: $CORE" >&2; exit 1; }

if [[ -e "$DEST" ]]; then
  BACKUP="${DEST}.backup.$(date +%Y%m%d-%H%M%S)"
  echo "Backing up existing theme to: $BACKUP"
  mv "$DEST" "$BACKUP"
fi

cp -a "$CORE" "$DEST"
cp -a "$SELF_DIR/overrides/." "$DEST/"

MAIN="$DEST/assets/scss/main.scss"
python3 - "$MAIN" <<'PY2'
from pathlib import Path
import sys
p=Path(sys.argv[1])
text=p.read_text()
lines=[ln for ln in text.splitlines() if '@use "includes/sentinalsprime"' not in ln and '@use "includes/phase3"' not in ln]
p.write_text('@use "includes/sentinalsprime";\n'+'\n'.join(lines)+'\n')
PY2

cd "$DEST"
command -v corepack >/dev/null 2>&1 && corepack enable >/dev/null 2>&1 || true
if [[ ! -d node_modules ]]; then yarn install; fi
rm -rf static
yarn build

"$SELF_DIR/verify.sh" "$DEST"

echo "Installed verified SentinalsPrime theme: $DEST"
