# SentinalsPrime Final Verified Theme v2

This is the single package to keep. You do **not** need any Phase 1–18 archive after this.

It contains every final SentinalsPrime customization after auditing the supplied phase ZIPs.

## Fresh install (recommended)

```bash
unzip sentinalsprime-theme-final-verified-v2.zip
cd sentinalsprime-theme-final-verified-v2
chmod +x install.sh
./install.sh ~/CTFd
```

The installer:
1. copies the local CTFd `core` theme to `CTFd/themes/sentinalsprime`;
2. overlays the final verified SentinalsPrime files;
3. keeps only one SCSS import: `@use "includes/sentinalsprime";`;
4. runs `yarn install` when needed and performs a clean `yarn build`;
5. verifies the final CSS, scoreboard entry, favicon set, notifications, and templates.

Then:

```bash
cd ~/CTFd
docker compose restart
```

Select `sentinalsprime` in Admin → Config → Theme if necessary.

## Update an existing SentinalsPrime theme

```bash
chmod +x update-existing.sh
./update-existing.sh ~/CTFd
```

## Materialize a complete folder without building

```bash
chmod +x materialize.sh
./materialize.sh ~/CTFd /tmp/sentinalsprime
```

That creates a complete standalone `sentinalsprime` source folder by combining the target installation's matching `core` theme with the final overrides. You can then archive or copy that resulting folder.

## Audit

See `AUDIT.md` for the exact source mapping and verification of all uploaded phases.
