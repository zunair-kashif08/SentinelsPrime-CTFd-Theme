#!/usr/bin/env bash
set -euo pipefail
DEST="${1:?Usage: verify.sh /path/to/sentinalsprime}"

test -f "$DEST/templates/base.html"
test -f "$DEST/templates/challenges.html"
test -f "$DEST/templates/scoreboard.html"
test -f "$DEST/templates/notifications.html"
test -f "$DEST/assets/js/scoreboard.js"
test -f "$DEST/assets/scss/includes/_sentinalsprime.scss"
test ! -f "$DEST/assets/scss/includes/_phase3.scss"
test ! -f "$DEST/assets/js/sentinals_scoreboard.js"

grep -q 'Assets.js("assets/js/scoreboard.js")' "$DEST/templates/scoreboard.html"
grep -q -- '--sentinalsprime-build-phase: 18' "$DEST/assets/scss/includes/_sentinalsprime.scss"
grep -q 'AGGREGATE_TOOLTIP_LIMIT' "$DEST/assets/js/scoreboard.js"
grep -q 'scoreAtTimestamp' "$DEST/assets/js/scoreboard.js"

test -f "$DEST/assets/img/favicon.svg"
test -f "$DEST/assets/img/favicon.ico"
test -f "$DEST/assets/img/favicon-32x32.png"
test -f "$DEST/assets/img/apple-touch-icon.png"

if [[ -f "$DEST/static/manifest.json" ]]; then
  grep -q 'scoreboard' "$DEST/static/manifest.json"
  grep -R -- '--sentinalsprime-build-phase:18\|--sentinalsprime-build-phase: 18' "$DEST/static" --include='*.css' >/dev/null
fi

echo "SentinalsPrime verification passed."
